class MyCircularQueue:
    
    def __init__(self, k: int):
        self.size = k 
        self.items = [None] * self.size 
        self.front = -1
        self.rear = -1

        

    def enQueue(self, value: int) -> bool:
        if self.isFull():
            return False
        else:
            if self.rear + 1 == self.size:
                self.rear = 0
            else:
                self.rear +=1
                if self.front == -1:
                    self.front =0
            self.items[self.rear] = value
            return True
        

    def deQueue(self) -> bool:
        if self.isEmpty():
            return False
        else:
            first_elem = self.items[self.front]
            start = self.front
            if self.front == self.rear:
                self.front = -1
                self.rear =-1
            elif self.front + 1 == self.size:
                self.front = 0
            else:
                self.front +=1
            self.items[start] = None
            return True

        

    def Front(self) -> int:
        return  -1 if self.items[self.front] is None else self.items[self.front]
        

    def Rear(self) -> int:
        return -1 if self.items[self.rear]  is None else self.items[self.rear]

    def isEmpty(self) -> bool:
        if self.rear == -1:
            return True
        return False
        

    def isFull(self) -> bool:
        if self.rear + 1 == self.front:
            return True
        elif self.front == 0 and self.rear + 1 == self.size:
            return True
        else:
            return False
        


# Your MyCircularQueue object will be instantiated and called as such:

myCircularQueue = MyCircularQueue(3);
print(myCircularQueue.enQueue(1))
print(myCircularQueue.enQueue(2))
print(myCircularQueue.enQueue(3))
print(myCircularQueue.enQueue(4))
print(myCircularQueue.items)
print(myCircularQueue.Rear())
print(myCircularQueue.isFull())
print(myCircularQueue.deQueue())
print(myCircularQueue.items)
print(myCircularQueue.enQueue(4))
print(myCircularQueue.Rear())
print(myCircularQueue.items)