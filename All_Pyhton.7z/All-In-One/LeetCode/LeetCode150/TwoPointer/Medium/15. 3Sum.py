from collections import defaultdict
from typing import List


class Solution:
    def threeSum1(self, nums: List[int]) -> List[List[int]]:
        res =  {}
        for i in range(len(nums)-2):
            for j in range(i + 1, len(nums)-1):
                for k in range(j + 1,len(nums)):
                    if (nums[i] + nums[j] + nums[k]) == 0:
                        val = "".join([str(x) for x in sorted([nums[i],nums[j],nums[k]])])
                        if val not in res:
                            res[val] = [nums[i],nums[j],nums[k]]

        return res.values()

    def threeSum(self, nums: List[int]) -> List[List[int]]:
        nums.sort()
        print(nums)
        res = []
        for i , a in enumerate(nums):
            if i > 0 and a == nums[i - 1]:
                continue

            l , r = i + 1 , len(nums)-1
            while l< r:
                threeSum = a + nums[l] + nums[r]
                if threeSum > 0:
                    r -= 1
                elif threeSum < 0:
                    l += 1
                else:
                    res.append([a,nums[l],nums[r]])
                    l += 1
                    while nums[l] == nums[l-1] and l < r:
                        l += 1

        return res







s = Solution()
print(s.threeSum(nums = [-1,0,1,2,-1,-4]))