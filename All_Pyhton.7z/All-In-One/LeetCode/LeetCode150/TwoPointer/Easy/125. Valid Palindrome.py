class Solution:
    def isPalindrome(self, s: str) -> bool:
        _str = ""
        for x in s:
            if x.isalnum():
                _str += x.lower()

        n = len(_str)
        for x in range(n//2):
            if _str[x] != _str[n-1-x]:
                return False
        return True




s = Solution()
print(s.isPalindrome(s = "race a car"))