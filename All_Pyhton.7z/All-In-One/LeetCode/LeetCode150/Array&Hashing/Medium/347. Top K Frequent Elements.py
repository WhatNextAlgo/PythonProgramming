from collections import defaultdict
from typing import List


class Solution:
    def topKFrequent(self, nums: List[int], k: int) -> List[int]:
        count = {}
        freq = [[] for x  in range(len(nums) + 1)]
        for x in nums:
            count[x] = 1 + count.get(x,0)

        for key,val in count.items():
            freq[val].append(key)

        res = []
        for x in range(len(freq)-1,-1,-1):
            for f in freq[x]:
                res.append(f)
                if len(res) == k:
                    return res



s = Solution()
print(s.topKFrequent(nums = [1,1,1,2,2,3], k = 2))