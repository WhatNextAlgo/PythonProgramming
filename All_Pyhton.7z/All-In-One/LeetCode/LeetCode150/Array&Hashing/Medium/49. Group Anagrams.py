from collections import defaultdict
from typing import List


class Solution:
    def groupAnagrams(self, strs: List[str]) -> List[List[str]]:
        d = defaultdict(list)
        
        for x in strs:
            d[str(sorted(x))].append(x)
        return d.values()


s = Solution()
print(s.groupAnagrams(strs = ["eat","tea","tan","ate","nat","bat"]))