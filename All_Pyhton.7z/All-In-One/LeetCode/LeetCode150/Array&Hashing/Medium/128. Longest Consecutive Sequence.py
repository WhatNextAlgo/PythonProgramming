from typing import List


class Solution:
    def longestConsecutive(self, nums: List[int]) -> int:
        unique = set(nums)
        longest = 0
        for x in nums:
            if (x - 1) not in unique:
                length = 1
                while (x + length) in unique:
                    length += 1
                longest = max(longest,length)
        return longest


s = Solution()
print(s.longestConsecutive(nums = [0,3,7,2,5,8,4,6,0,1]))