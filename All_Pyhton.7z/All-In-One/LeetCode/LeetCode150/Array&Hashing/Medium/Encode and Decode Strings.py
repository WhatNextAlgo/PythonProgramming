from typing import List


class Solution:

    def encode(self,strs:List[str]):
        res = ""
        for x in strs:
            res += str(len(x)) + "#" + x

        return res

    def decode(self,strs) -> List[str]:
        res, i = [],0

        while i < len(strs):
            j = i
            while strs[j] != "#":
                j += 1
            length = int(strs[i:j])
            res.append(strs[j + 1:j + 1 +length])
            i = j + 1 + length
        return res

        



s = Solution()
encode_str = s.encode(strs =["neet","code","sumit","maurya"])
print(encode_str)
print(s.decode(strs =encode_str))
