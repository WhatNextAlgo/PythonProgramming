class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        last_seen = {}
        l = 0
        max_length = 0
        for x in range(len(s)):
            if s[x] in last_seen:
                print(last_seen,l)
                l = max(last_seen[s[x]],l)
            last_seen[s[x]] = x + 1 
            max_length = max(max_length,x-l + 1)

        return max_length
    
    def lengthOfLongestSubstring1(self, s: str) -> int:
        charSet = set()
        max_length,l = 0,0
        for r in range(len(s)):
            while s[r] in charSet:
                charSet.remove(s[l])
                l += 1 
            charSet.add(s[r])
            
            max_length = max(max_length,r -l + 1)
        return max_length


s = Solution()
print(s.lengthOfLongestSubstring(s = "pwwkew"))