from typing import List


class Solution:
    def maxProfit1(self, prices: List[int]) -> int:
        min_val = prices[0]
        max_profit = 0
        for x in range(1,len(prices)):
            if min_val > prices[x]:
                min_val = prices[x]
            else:
                if max_profit < (prices[x] - min_val):
                    max_profit = (prices[x] - min_val)
        return max_profit

    def maxProfit(self, prices: List[int]) -> int:
        res = 0
        l = 0
        for r in range(1,len(prices)):
            if prices[r] < prices[l]:
                l = r
            res = max(res,prices[r] -prices[l])
        return res



s = Solution()
print(s.maxProfit(prices = [7,6,4,3,1]))