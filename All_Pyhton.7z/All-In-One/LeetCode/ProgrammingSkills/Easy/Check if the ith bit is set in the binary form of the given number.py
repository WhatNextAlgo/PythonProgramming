def checknthSetBit(n,i):
    if n & (1 << i):
        return True
    return False


