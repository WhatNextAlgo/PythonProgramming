from typing import List


def convertStr(s1:str,s2:str,index:List[int]) -> str:
        charIndex = [0] * 26 # 26 letter
        for x in index:
            charIndex[ord(s1[x-1]) - ord('a')] += 1    #updated the index of respective letter 
        charVal = ""
        for  ind,c in enumerate(charIndex):
            if c != 0:
                charVal = chr(ord('a') + ind)
                break
        n = list(s2)
        for x in index:
            n[x-1] = charVal
        
        return "".join(n)



#print(convertStr(s1="abcab",s2="aabab",index=[2,3,5]))


def mergeList(l1,l2):
    if not l1:
        return l2
    if not l2:
        return l1

    n,m = len(l1),len(l2)
    l3 = []

    i = 0
    j = 0
    k = 0
    while i < n and j < m:
        if l1[i] < l2[j]:
            l3.append(l1[i])
            i += 1
        else: 
            l3.append(l2[j])
            j += 1
    
    while i < n:
        l3.append(l1[i])
        i += 1
    
    while j < m:
        l3.append(l2[j])
        j += 1

    return l3

#print(mergeList(l1 =[10,20,30],
# l2 =[7,12,18,22,45]))

# print(mergeList(l1 =[],
# l2 =[7,12,18,22]))


def per(h,w,n,b1):
    p = {}
    for x in h+w:
        p[x] = 1 + p.get(x,0)


    for x in b1:
        if p.get(x,-1) <=0:
            return "No"
        p[x] -= 1
    return "YES"
        
# h = input("Enter husband = ")
# w = input("Enter wife = ") 
# n = input("Enter no of building = ") 
# b = "".join(input("Enter buildings= ").split())

#print(per(h,w,n,b))

#print(per("amile","emile",1,"mike"))


def solution(s,A):
    if s == "" or A == []:
        return s
    res = s[0]
    i = A[0]
    while i != 0:
        res += s[i]
        i = A[i]
    return res

print(solution(s="cdeo",A=[3,2,0,1]))




