# Definition for a binary tree node.
from typing import Optional


class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def pruneTree(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        
        def helper(node):
            if not node:return False
            
            left_has_one = helper(node.left)
            right_has_one = helper(node.right)
            
            if not left_has_one:
                node.left = None
                
            if not right_has_one:
                node.right = None
                
                
            return node.val or left_has_one or right_has_one
        
        return root if helper(root) else None