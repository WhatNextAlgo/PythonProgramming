def getConcatenation(nums):
    return nums + nums

print(getConcatenation([1,3,2,1]))