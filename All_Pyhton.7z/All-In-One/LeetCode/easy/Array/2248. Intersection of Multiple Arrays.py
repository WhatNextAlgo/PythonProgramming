def intersection(nums):
    pass

print(intersection())