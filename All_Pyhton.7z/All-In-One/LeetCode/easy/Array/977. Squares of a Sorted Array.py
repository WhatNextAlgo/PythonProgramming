def sortedSquares(nums):
    return sorted([x * x for x in nums])

print(sortedSquares(nums = [-7,-3,2,3,11]))