class Solution:
    def wordPattern(self, pattern: str, s: str) -> bool:
        arr = s.split(" ")
        if len(pattern) != len(arr):
            return False

        return len(set(zip(pattern,arr)))  == len(set(pattern))


s = Solution()
print(s.wordPattern(pattern = "abba", s = "dog cat cat dog"))
print(s.wordPattern(pattern = "abba", s = "dog cat cat fish"))
