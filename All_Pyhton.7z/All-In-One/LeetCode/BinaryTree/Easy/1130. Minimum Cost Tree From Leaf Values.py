from typing import List


class Solution:
    def mctFromLeafValues(self, arr: List[int]) -> int:
        total = 0
        pass
        
        