import collections
from typing import List


class Solution:
    def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        parent = {}
    
        def find(x):
            if x not in parent:
                return x
            
            if x != parent[x]:
                parent[x] = find(parent[x])
                
            return parent[x]
            
            
        def union(x,y):
            a, b = find(x), find(y)
            
            if a != b:
                parent[b] = a
        
        dict1 = collections.defaultdict(list)
        
        for i, j in dislikes:
            dict1[i].append(j)
            dict1[j].append(i)
            
            
        for key, val in dict1.items():
            for v in val:
                if find(key) == find(v):
                    return False
                else:
                    union(val[0], v)
                
        return True 

s = Solution()
print(s.possibleBipartition(n = 5, dislikes = [[1,2],[2,3],[3,4],[4,5],[1,5]]))