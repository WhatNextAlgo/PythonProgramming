from typing import List


class Solution:
    def minimumJumps(self, forbidden: List[int], a: int, b: int, x: int) -> int:
        queue, forbidden = [(x,0,True)], set(forbidden)
        lim = max(max(forbidden),x)+a+b
        while queue:
            curr,jumps,is_b = queue.pop(0)
            if curr in forbidden or not 0 <= curr <= lim:
                continue
            forbidden.add(curr)
            if curr==0:
                return jumps
            if is_b:
                queue.append((curr+b,jumps+1,False))
            queue.append((curr-a,jumps+1,True))
        return -1


s = Solution()
print(s.minimumJumps(forbidden = [14,4,18,1,15], a = 3, b = 15, x = 9))