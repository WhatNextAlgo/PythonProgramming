from typing import List


class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
    
        def bfs(vertex,visited):
            colour = {vertex: 0}
            visited.add(vertex)
            q = []
            q.append(vertex)
            while q:
                current = q.pop(0)
        
                next_colour = 1 - colour[current] # switch colour
                for dest in graph[current]:
                    if dest not in visited:
                        visited.add(dest)
                        colour[dest] = next_colour
                        q.append(dest)
                    else:
                        if colour.get(dest,-1) != next_colour:
                            return False
            return True

        bipartite = True
        visited = set()
        for v in range(len(graph)):
            if v not in visited:
                if not bfs(v,visited):
                    bipartite = False

        return bipartite


s = Solution()
print(s.isBipartite(graph = [[1,2,3],[0,3,4],[0,3],[0,1,2],[1]]))
        

        