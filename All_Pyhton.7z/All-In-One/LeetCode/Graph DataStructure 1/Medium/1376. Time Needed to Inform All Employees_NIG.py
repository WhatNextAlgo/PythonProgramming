
import collections
from typing import List


class Solution:
    def numOfMinutes(self, n: int, headID: int, manager: List[int], informTime: List[int]) -> int:
        adj = collections.defaultdict(list)
        for i,m in enumerate(manager):
            adj[m].append(i)
        q = []
        q.append((informTime[headID],headID))
        res = 0
        while q:
            time, node = q.pop(0)
            res = max(res,time)
            for e in adj[node]:
                q.append((time + informTime[e],e))
        return res

s = Solution()
print(s.numOfMinutes(n = 6, headID = 2, manager = [2,2,-1,2,2,2], informTime = [0,0,1,0,0,0]))
print(s.numOfMinutes(7,
6,
[1,2,3,4,5,6,-1],
[0,6,5,4,3,2,1]))
