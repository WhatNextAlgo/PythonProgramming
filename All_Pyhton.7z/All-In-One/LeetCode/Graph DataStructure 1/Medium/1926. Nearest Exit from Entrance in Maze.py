from typing import List


class Solution:

    def nearestExit(self, maze: List[List[str]], entrance: List[int]) -> int:
        ROWS,COLS = len(maze),len(maze[0])
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        visited = ' '
        entrance = tuple(entrance)
        maze[entrance[0]][entrance[1]] = visited
        q = [(entrance, 0)]
        while q:
            new_q = []
            for (r, c), step in q:
                if (r, c) != entrance and \
                   (r in (0, len(maze)-1) or c in (0, len(maze[0])-1)):
                    return step
                for dr, dc in directions:
                    nr, nc = r+dr, c+dc
                    if not (0 <= nr < ROWS and
                            0 <= nc < COLS and
                            maze[nr][nc] == '.'):
                        continue
                    maze[nr][nc] = visited
                    q.append(((nr, nc), step+1))
            q = new_q
        return -1

        




s = Solution()
print(s.nearestExit(maze = [["+","+",".","+"],
                            [".",".",".","+"],
                            ["+","+","+","."]], 
                            entrance = [1,2]))

print(s.nearestExit( maze = [["+","+","+"],[".",".","."],["+","+","+"]], entrance = [1,0]))
        