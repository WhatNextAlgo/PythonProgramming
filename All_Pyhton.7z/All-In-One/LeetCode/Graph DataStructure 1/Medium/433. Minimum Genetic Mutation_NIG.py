from typing import List


class Solution:
    def minMutation(self, start: str, end: str, bank: List[str]) -> int:
        bank = set(bank)
        if not end in bank:
            return -1
        
        q, step = [start],0
        while q:
            new_q = []
            for s in q:
                for i in range(8):
                    for x in ['A','T','G','C']:
                        if s[i] == x:
                            continue
                        k = s[:i] + x + s[i + 1:]
                        if k == end:
                            return step + 1
                        if k in bank:
                            bank.remove(k)
                            new_q.append(k)
            q = new_q
            step += 1

        return -1




s = Solution()
print(s.minMutation(start = "AAAAACCC", end = "AACCCCCC", bank = ["AAAACCCC","AAACCCCC","AACCCCCC"]))