from typing import List


class Solution:
    def updateMatrix(self, mat: List[List[int]]) -> List[List[int]]:
        directions = [[-1,0], [1,0], [0,-1], [0,1]]
        
        def isValid(r, c):
            return r in range(len(mat)) and c in range(len(mat[r]))
        

        row, col = len(mat), len(mat[0])
        q = []
        for r in range(row):
            for c in range(col):
                
                if mat[r][c] == 0:
                    q.append([r,c])
                
                else:
                    mat[r][c] = -1
        print(mat)
                    
        # BFS 
        while q:
            r, c = q.pop(0)
            for row, col in directions:
                movx = r + row
                movy = c + col
                if isValid(movx, movy) and mat[movx][movy] == -1:
                    mat[movx][movy] = mat[r][c] + 1
                    q.append([movx, movy])
                
        return mat

        
        



s = Solution()
print(s.updateMatrix(mat = [[0,0,0],[0,1,0],[1,1,1]]))