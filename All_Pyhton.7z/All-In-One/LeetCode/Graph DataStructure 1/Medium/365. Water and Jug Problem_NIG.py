class Solution:
    def canMeasureWater(self, jug1Capacity: int, jug2Capacity: int, targetCapacity: int) -> bool:
        x,y,z = jug1Capacity,jug2Capacity,targetCapacity
        def gcd(a, b):
            if(b == 0):
                return a
            return gcd(b, a % b)

        if(x + y < z):
            return False
    
        if(x == 0 and y == 0):
            if(z == 0):
                return True
    
            else:
                return False
    
        if(z % gcd(x, y) == 0):
            return True
    
        else:
            return False

s = Solution()
print(s.canMeasureWater(jug1Capacity = 1, jug2Capacity = 2, targetCapacity = 3))