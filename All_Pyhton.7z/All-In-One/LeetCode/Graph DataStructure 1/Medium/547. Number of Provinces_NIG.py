from typing import List


class Solution:
    def findCircleNum(self, isConnected: List[List[int]]) -> int:
        visited = set()
        res = 0
        def dfs(i):
            visited.add(i)
            for j in range(len(isConnected[i])):
                if j != i and isConnected[i][j] == 1 and j not in visited:
                    dfs(j)

        for i in range(len(isConnected)):
            if i not in visited:
                dfs(i)
                res += 1
        return res