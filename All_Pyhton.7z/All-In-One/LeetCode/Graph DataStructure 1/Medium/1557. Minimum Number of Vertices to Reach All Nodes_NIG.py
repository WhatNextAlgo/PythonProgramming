import collections
from typing import List


class Solution:
    def findSmallestSetOfVertices(self, n: int, edges: List[List[int]]) -> List[int]:
        visit = set()
        for u, v in edges:
            visit.add(v)
        vertex = set(range(n))
        ans = vertex - visit
        return list(ans)

        



s = Solution()
print(s.findSmallestSetOfVertices(n = 6, edges = [[0,1],[0,2],[2,5],[3,4],[4,2]]))