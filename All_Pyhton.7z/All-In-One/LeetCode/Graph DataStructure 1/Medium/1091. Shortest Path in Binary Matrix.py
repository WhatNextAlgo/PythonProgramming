from typing import List


class Solution:
    def shortestPathBinaryMatrix(self, grid: List[List[int]]) -> int:
        n = len(grid)
        if grid[0][0] or grid[n-1][n-1]: # src and dest  is not 0
            return -1
        directions = [[1,0], [-1,0], [0,1], [0,-1], [-1,-1], [1,1], [1,-1], [-1,1]] # 8-directions
        visit = set()
        q = [(0,0,1)]
        visit.add((0,0))
        while q:
            r ,c ,dist = q.pop(0)
            if r == n -1 and c ==  n-1:
                return dist
            
            for dr , dc in directions:
                ROW, COL = r + dr , c + dc
                if 0 <= ROW < n and 0 <= COL < n:
                    if (ROW,COL) not in visit and grid[ROW][COL] == 0:
                        visit.add((ROW,COL))
                        q.append((ROW,COL,dist + 1))

        return -1

s = Solution()
print(s.shortestPathBinaryMatrix(grid = [[0,0,0],[1,1,0],[1,1,0]]))

            

