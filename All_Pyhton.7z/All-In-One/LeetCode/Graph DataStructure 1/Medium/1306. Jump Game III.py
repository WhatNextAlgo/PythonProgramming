from operator import truediv
from typing import List


class Solution:
    def canReach(self, arr: List[int], start: int) -> bool:
        n = len(arr)
        q = []
        q.append(start)
        seen = [False] * n
        while q:
            node = q.pop(0)
            if arr[node] == 0:
                return True
            if seen[node]:
                continue

            if (node - arr[node] >= 0):
                q.append(node - arr[node])
            if (node + arr[node] < n):
                q.append(node + arr[node])
            seen[node] = True
        return False

s = Solution()
print(s.canReach(arr = [3,0,2,1,2], start = 2))