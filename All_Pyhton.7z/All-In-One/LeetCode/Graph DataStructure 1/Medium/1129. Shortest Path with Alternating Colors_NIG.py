import collections
from typing import List
#https://wenxu1024.github.io/blog.html


class Solution:
    def shortestAlternatingPaths(self, n: int, redEdges: List[List[int]], blueEdges: List[List[int]]) -> List[int]:
        rednei = collections.defaultdict(list)
        bluenei = collections.defaultdict(list)
        for u,v in redEdges:
            rednei[u].append(v)
        
        for u,v in blueEdges:
            bluenei[u].append(v)
        
        ans = [-1 for _ in range(n)]
        q= []
        q.append((0,'grey',0))
        found = set([])
        while q:
            x,color,level = q.pop(0)
            if ans[x] == -1:
                ans[x] = level
            
            if color != 'red' and color != "blue":
                for nei in rednei[x]:
                    if str(x)+'_'+str(nei)+'_'+'red' not in found:
                        q.append((nei, 'red', level + 1))
                        found.add(str(x)+'_'+str(nei)+'_'+'red')
                
                for nei in bluenei[x]:
                    if str(x)+'_'+str(nei)+'_'+'blue' not in found:
                        q.append((nei, 'blue', level + 1))
                        found.add(str(x)+'_'+str(nei)+'_'+'blue')

            elif color == 'red':
                for nei in bluenei[x]:
                    if str(x)+'_'+str(nei)+'_'+'blue' not in found:
                        q.append((nei, 'blue', level + 1))
                        found.add(str(x)+'_'+str(nei)+'_'+'blue')
            elif color == 'blue':
                for nei in rednei[x]:
                    if str(x)+'_'+str(nei)+'_'+'red' not in found:
                        q.append((nei, 'red', level + 1))
                        found.add(str(x)+'_'+str(nei)+'_'+'red')

        return ans


s = Solution()
print(s.shortestAlternatingPaths(n = 3, redEdges = [[0,1]], blueEdges = [[2,1]]))