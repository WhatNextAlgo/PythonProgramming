from queue import Queue
from typing import List
class Solution:
    def floodFill(self, image: List[List[int]], sr: int, sc: int, color: int) -> List[List[int]]:
        def flood_fill(grid, i, j, new_color):
            n = len(grid)
            m = len(grid[0])
            old_color = grid[i][j]
            if old_color == new_color:
                return
            queue = Queue()
            queue.put((i, j))
            while not queue.empty():
                i, j = queue.get()
                if i < 0 or i >= n or j < 0 or j >= m or grid[i][j] != old_color:
                    continue
                else:
                    grid[i][j] = new_color
                    queue.put((i+1, j))
                    queue.put((i-1, j))
                    queue.put((i, j+1))
                    queue.put((i, j-1))
        
        flood_fill(image, sr, sc, color)
                    
        return image

s = Solution()
print(s.floodFill(image = [[1,1,1],[1,1,0],[1,0,1]], sr = 1, sc = 1, color = 2))