lst1 = [20,30,40,60]
lst2 = [10,20,40,50]

a = list(set(lst1 + lst2))
print('The Union of two lists is:',a)