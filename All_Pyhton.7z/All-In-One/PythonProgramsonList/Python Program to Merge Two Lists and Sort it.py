lst1 = [10,20,35,55,71]
lst2 = [5,37]

lst3 = sorted(lst1 + lst2)
print("Sorted list is:",lst3)