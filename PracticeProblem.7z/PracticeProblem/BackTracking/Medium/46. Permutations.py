from typing import List


class Solution:
    def permute(self, nums: List[int]) -> List[List[int]]:
        result = []

        # base case
        if (len(nums) == 1):
            return [nums[:]] # make a copy of it

        for i in range(len(nums)):
            n = nums.pop(0)
            prems = self.permute(nums)
            for prem in prems:
                prem.append(n)
            result.extend(prems)
            nums.append(n)

        return result


s = Solution()
print(s.permute(nums = [1,2,3]))