from collections import Counter
from typing import List



class Solution:
    def maxLength(self, arr: List[str]) -> int:
        charSet = set()

        def overlap(charset,s):
            c = Counter(charSet) + Counter(s)
            return max(c.values()) > 1
            prev = set()
            for c in s:
                if c in charSet or c in prev:
                    return True
                prev.add(c)
            return False

        def dfs(i):
            if i == len(arr):
                return len(charSet)
            res = 0
            if not overlap(charSet,arr[i]):
                for c in arr[i]:
                    charSet.add(c)
                
                res = dfs(i + 1)
                # clean up charSet for next decision
                for c in arr[i]:
                    charSet.add(c)
            return max(res,dfs(i + 1)) # don't concatenate arr[i]

        return dfs(0)

        

                

s = Solution()
print(s.maxLength(arr = ["un","iq","ue"]))