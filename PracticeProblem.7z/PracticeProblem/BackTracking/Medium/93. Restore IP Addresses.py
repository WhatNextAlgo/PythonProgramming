from typing import List



class Solution:
    def restoreIpAddresses(self, s: str) -> List[str]:
        res = []
        if len(s) > 12 :return  res
    
        def dfs(i,dots,curIP):
            if dots == 4 and i == len(s):
                res.append(curIP[:-1])
                return 

            for j in range(i,min(i + 3,len(s))):
                if int(s[i:j + 1]) < 256 and s[i] != "0":
                    dfs(j + 1,dots + 1,curIP + s[i:j + 1] + ".")

        dfs(0,0,"")

        return res
        

s = Solution()
print(s.restoreIpAddresses(s = "25525511135"))