def climbingLeaderboard(ranked, player):
    ranked = sorted(list(set(ranked)))
    player.sort()
    res = []
    i = 0
    n = len(ranked)
    for p in player:
        while i < n and ranked[i] <= p:
            i += 1

        res.append(n - i + 1)
    return res




def bfs(n, m, edges, s):
    adj =  {src : [] for src in range(1,n + 1)}
    for u,v in edges:
        adj[u].append(v)
        adj[v].append(u)
    
    visit = set()
    res = [-1] * (n + 1)
    q = [(s, 0)]
    res[s] = 0
    
    while q :
        for _ in range(len(q)):
            node, w = q.pop(0)
            print(node,w)
            for nei in adj.get(node,[]):
                if nei not in visit:
                    q.append((nei,6 + w))
                    visit.add(nei)
                    res[nei] = 6 + w
    del res[s]
    return res[1:]

print(bfs(5,3,[[1,2],[1,3],[3,4]],1))



# print(climbingLeaderboard1([100, 90, 90, 80, 75, 60],[50, 65, 77, 90, 102]))
print(climbingLeaderboard([100, 100, 50, 40, 40, 20, 10],[5, 25,50, 120]))


def getWays(n, c):
    dp = {}

    def dfs(index,total):
        if total == n:
            return 1

        if total > n:
            return 0
        
        if (index,total) in dp:
            return dp[(index,total)]
        
        for i ,coin in enumerate(c):
            dp[(index,total)] = dfs(i,total + coin)

        return dp[(index,total)]
    dfs(0,0)
    print(dp)
    
    # amount = n
    
    # dp =[amount + 1] * (amount + 1)
    # dp[0] = 0

    # for a in range(1,amount + 1):
    #     for coin in c:
    #         if a - coin >= 0:
    #             # target = 7
    #             # dp[7] = 1(no of coins) + dp[6]
    #             # dp[4] = 1 + dp[3]
    #             dp[a] = min(dp[a],1 + dp[a -coin])

    # return dp[amount] if dp[amount] != amount + 1 else -1

print(getWays(4,[1,2,3]))