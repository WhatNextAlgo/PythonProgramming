from typing import List
from unittest import case

from numpy import diag


class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        ROWS,COLS = len(matrix),len(matrix[0])
        cache = {}

        def dfs(r,c):
            if (r < 0 or r >= ROWS or c < 0 or c >= COLS):
                return 0

            if (r,c) not in cache:
                left = dfs(r, c + 1)
                down = dfs(r + 1, c)
                diag = dfs(r + 1 ,c + 1)

                cache[(r,c)] = 0
                if matrix[r][c] == "1":
                    cache[(r,c)] = 1 + min(left,down,diag)

            return cache[(r,c)]

        dfs(0,0)
        return max(cache.values()) ** 2

s = Solution()
print(s.maximalSquare(matrix = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]))
print(s.maximalSquare(matrix = [["0","1"],["1","0"]]))