from typing import List


class Solution:
    def combinationSum4(self, nums: List[int], target: int) -> int:
        
        dp = {}
        def dfs(i,total):
            if target == total:
                return 1

            if total > target:
                return 0

            if (i,total) in dp:
                return dp[(i,total)]

            dp[(i,total)] =0
            for n in nums:
                if n < target:
                    dp[(i,total)] += dfs(i,total + n)

            return dp[(i,total)]

        res = dfs(0,0)
        print(dp)
        return res

        

    def combinationSum41(self, nums: List[int], target: int) -> int:
        dp = {0:1}

        for total in range(1, target + 1):
            dp[total] = 0
            for n in nums:
                dp[total] += dp.get(total -n,0)

        print(dp)
        return dp[total]


s = Solution()
print(s.combinationSum4(nums = [1,2,3], target = 5))