from matplotlib.colors import TwoSlopeNorm


class Solution:
    #TOP-DOWN Memoization
    def climbStairs(self, n: int) -> int:
        dp = {}

        def dfs(index,total):
            if total == n:
                return 1
            if total > n:
                return 0

            if (index,total) in dp:
                return dp[(index,total)]

            dp[(index,total)] = (dfs(index + 1,total + 1 ) + dfs(index + 1,total + 2 ))
            return dp[(index,total)]
        res = dfs(0,0)
        return res

    def climbStairs(self, n: int) -> int:
        one , two = 1,1
        for _ in range(n-1):
            temp = one
            one = one + two
            two = temp
        return one

s = Solution()
print(s.climbStairs(n = 4))

