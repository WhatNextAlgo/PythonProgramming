def even_genertor(max = 0):
    n = 2
    while n <= max:
        yield n
        n += 2


numbers = even_genertor(10)
for n in numbers:
    print(n)


def rev_str(my_str):
    length = len(my_str)

    for x in range(length -1,-1,-1):
        yield my_str[x]


for s in rev_str("hello"):
    print(s)

def generate_fibonacc():
    n1 = 0
    n2 =  1
    while True:
        yield n1
        n1,n2 = n2, n1 + n2

seq = generate_fibonacc()
print(next(seq))
print(next(seq))
print(next(seq))
print(next(seq))
print(next(seq))
print(next(seq))

#Pipelining Generators

def fibonacci(max):
    x ,y = 0,1
    for _ in range(max):
        x , y = y , x + y
        yield x

def square(nums):
    for num in nums:
        yield num ** 2

print(sum(square(fibonacci(10))))