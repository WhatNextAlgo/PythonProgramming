class PowTwo:

    def __init__(self,max = 0):
        self.__max = max
        self.n = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.n <= self.__max:
            result = 2 ** self.n
            self.n += 1
            return result
        else:
            raise StopIteration


p = PowTwo(10)

for i in p:
    print(i)