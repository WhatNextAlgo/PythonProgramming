def print_msg(msg):
    def printer():
        print(msg)
    return printer

author = print_msg("Sumit")
author()
del print_msg
author()

def make_multiplier_of(n):
    def multipler(x):
        return x * n
    return multipler

times3 = make_multiplier_of(3)
times5 = make_multiplier_of(5)
print(times5(times3(2)))
