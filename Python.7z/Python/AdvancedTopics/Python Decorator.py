def inc(x):return x + 1
def dec(x):return x -1 

def operate(func,x):
    result = func(3)
    return result

print(operate(inc,3))
print(operate(dec,3))



def display_info(func):
    def inner():
        print("Executing", func.__name__,"function")
        func()
        print("Finished execution.")

    return inner

@display_info
def printer():print("Hello world!")

printer()

def smart_divide(func):

    def inner(a,b):
        print(f"Dividing {a} by {b}")
        if b == 0:
            print("Cannot divide by 0!")
            return
        return func(a,b)
    return inner

@smart_divide
def divide(a,b):
    return a/b

print(divide(10,2))
print(divide(2,0))

def star(func):
    def inner(*args, **kwargs):
        print("*" * 30)
        func(*args, **kwargs)
        print("*" * 30)
    return inner


def percent(func):
    def inner(*args, **kwargs):
        print("%" * 30)
        func(*args, **kwargs)
        print("%" * 30)
    return inner


@star
@percent
def printer(msg):
    print(msg)


printer("Hello")

