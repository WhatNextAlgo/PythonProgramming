class Celsius:
    def __init__(self,temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    #Solution 1:

    # #getter method
    # def get_temperature(self):
    #     return self._temperature 
    
    # #setter method
    # def set_temperature(self,value):
    #     if value < -273.15:
    #         raise ValueError('Temperature below -273.15 is not possible.')
    #     self._temperature = value
    # # creating a property object
    # temperature = property(get_temperature,set_temperature)
    @property
    def temperature(self):
        return self._temperature
    
    @temperature.setter
    def temperature(self,value):
        if value < -273.15:
            raise ValueError("Temperature below -273.15 is not possible.")
        self._temperature = value


if __name__ == "__main__":
    human = Celsius(37)
    print(human.temperature)
    print(human.to_fahrenheit())
    human.temperature = 100
    print(human.temperature)
    print(human.to_fahrenheit())
    human.temperature = -300
