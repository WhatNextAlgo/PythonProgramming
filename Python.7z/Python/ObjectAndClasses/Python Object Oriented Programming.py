class Parent:
    #class Attribute
    species = "Bird"

    #instance attribute
    def __init__(self,name,age):
        self.name = name
        self.age = age


#instantiate the Parrot Class
blu = Parent("Blu",10)
woo = Parent("Woo",15)

# access the class attribute
print("Blu is a {}".format(blu.__class__.species))
print("Woo is a {}".format(woo.__class__.species))

# access instance attribute
print("{} is {} years old.".format(blu.name,blu.age))
print("{} is {} years old.".format(woo.name,woo.age))

