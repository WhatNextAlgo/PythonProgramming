class Point:
    def __init__(self,x:int,y: int):
        self.x = x
        self.y = y

    def __add__(self,other):
        x = self.x + other.x
        y = self.y + other.y
        return Point(x,y)

    def __lt__(self,other):
        self_mag = (self.x ** 2) + (self.y ** 2)
        self_other = (other.x ** 2) + (other.y ** 2)
        return self_mag < self_other

    def __str__(self):
        return f"({self.x},{self.y})"

    

p1 = Point(1,2)
p2 = Point(2,3)

p3 = p1 + p2
print(p3)
print(p1 < p2)
print(p2 < p1)
