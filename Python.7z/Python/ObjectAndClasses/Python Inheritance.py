"""
Inheritance is a way of creating a new class for using details of an existing class without modifying it.
The newly formed class is a derived class (or child class).
Similarly, the existing class is a base class (or parent class).
"""

#Parent Class
class Bird:
    #initializer 
    def __init__(self):
        print("Bird is ready")

    #Instance Method
    def whoisThis(self):
        print("Bird")

    def swim(self):
        print("Swim faster")

# Derived / Child Class
class Penguin(Bird):
    #Initializer
    def __init__(self):
        # Call super() function
        super().__init__()
        print("Penguin is ready")

    def whoisThis(self):
        print("Penguin")

    def run(self):
        print("Run Faster")


peggy = Penguin()
peggy.whoisThis()
peggy.swim()
peggy.run()


class Polygon:
    def __init__(self,no_of_sides):
        self.n = no_of_sides
        self.slides = [0 for _ in range(no_of_sides)]

    def inputSlides(self):
        self.slides = [float(input(f"Enter side {str(i + 1)} : ")) for i in range(self.n)]

    def dispSlides(self):
        for i in range(self.n):
            print(f"Side {i + 1} : {self.slides[i]}")


class Triangle(Polygon):
    def __init__(self, no_of_sides):
        super().__init__(no_of_sides)

    def findArea(self):
        a,b,c = self.slides
        #calculate the semi-perimeter
        s = (a + b + c)/2
        area = (s * (s-a) * (s-b) * (s-c)) ** 0.5
        print(f"The area of triangle is {area}")


t = Triangle(3)
t.inputSlides()

t.dispSlides()
t.findArea()

