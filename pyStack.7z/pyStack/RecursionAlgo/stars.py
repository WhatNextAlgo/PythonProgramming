import turtle

bob = turtle.Turtle()
bob.getscreen().bgcolor("#994444")

bob.penup()
bob.goto((-200,100))
bob.pendown()
def Star(star,size):
    if size <= 10:
        return
    else:
        star.begin_fill()
        for i in range(5):
            star.forward(size)
            Star(star,size/3)
            star.left(216)
        star.end_fill()  

     


Star(bob,360)


turtle.done()