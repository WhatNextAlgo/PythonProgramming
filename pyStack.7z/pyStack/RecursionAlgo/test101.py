from pyspark import *
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.dbutils import DBUtils
spark =SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)
print(dbutils.fs.ls("/mnt/")) 