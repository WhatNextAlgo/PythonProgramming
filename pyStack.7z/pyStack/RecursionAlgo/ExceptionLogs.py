import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(pathname)s:%(asctime)s:%(levelname)s:%(message)s')

file_handler = logging.FileHandler('logDetails.log')
file_handler.setLevel(logging.ERROR)
file_handler.setFormatter(formatter)

#StreamHandler
#stream_handler = logging.StreamHandler()
#stream_handler.setFormatter(formatter)
logger.addHandler(file_handler)
#logger.addHandler(stream_handler)


def doFun():
    try:
        logger.info("Hii")
        logger.info("helllo"+10)
    except:
        v = logger.exception("Error Details")
        print("Console.log",v)



if __name__ =="__main__":
    doFun()
    

