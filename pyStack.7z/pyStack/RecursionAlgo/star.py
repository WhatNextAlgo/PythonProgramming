import turtle
import math

bob = turtle.Turtle()
bob.color("blue")
bob.speed(10)
#bob.begin_fill()
# for i in range(100):
#     bob.forward(200)
#     bob.left(170)

for i in range(200):
    bob.forward(10)
    bob.left(math.sin(i/10)* 25)
    bob.left(20)
 
#bob.end_fill()
turtle.done()

