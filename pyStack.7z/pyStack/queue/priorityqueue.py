
# Priority Queue implementation in Python
def heapify(arr,n,i):
    
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2

    #check if left element is largest w.r.t parent node
    if left < n and arr[left] > arr[i]:
        largest = left
    
    #check if right  element is largest w.r.t (parent/left)
    if right < n and arr[right] > arr[largest]:
        largest = right
    
    if largest != i:
        arr[largest], arr[i] = arr[i], arr[largest]
        heapify(arr,n,largest)

# Function to insert an element into the tree

def insert(array,num):
    size = len(array)

    if size == 0:
        array.append(num)
    else:
        array.append(num)
        for i in range(size//2-1,-1,-1):
            heapify(array,size,i)

def deleteNode(array,num):
    size = len(array)
    i = 0
    for i in range(size):
        if num == array[i]:
            break
    
    array[i], array[size-1] = array[size-1],array[i]

    array.remove(size-1)

    for i in range((len(array)//2)-1,-1,-1):
        heapify(array,len(array),i)


arr = []

insert(arr, 3)
insert(arr, 4)
insert(arr, 9)
insert(arr, 5)
insert(arr, 2)

print ("Max-Heap array: " + str(arr))

deleteNode(arr, 4)
print("After deleting an element: " + str(arr))