
class Node:
    def __init__(self,value=None):
        self.value = value
        self.next = None
class Stack:
    def __init__(self):
        self.head = None

    def is_empty(self):
        if self.head is None:
            return True
        else:
            return False

    def __str__(self):
        values = [str(x.value) for x in self]
        return "-->".join(values)

    def __iter__(self):
        curr = self.head
        while curr:
            yield curr
            curr = curr.next


    def push(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
        else:
            new_node.next = self.head
            self.head =  new_node

    def pop(self):
        if  self.is_empty():
            return "stack is empty"
        else:
            value = self.head.value
            self.head = self.head.next
            return value

    def peek(self):
        if  self.is_empty():
            return "stack is empty"
        else:
            value = self.head.value
            return value

    def clear(self):
        self.head = None




if __name__=="__main__":
    s = Stack()
    s.push(1)
    s.push(2)
    s.push(3)
    print(s)
    print(s.pop())
    print(s)
    print(s.peek())
    print(s.clear())


        
