
#calculate temperature

def get_input():
    lst = []
    numDays = int(input("How many day's temperature? "))

    for day in range(numDays):
        nextDays = int(input(f"Day {day + 1}'s high temp: "))
        lst.append(nextDays)
    
    avg = round(sum(lst)/numDays,2)
    print("\nAverage = " + str(avg))

    above = 0
    for i in lst:
        if i > avg:
            above += 1
    print(f"{above} day(s) above average temperature")


if __name__=="__main__":
    get_input()