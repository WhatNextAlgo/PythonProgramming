from insertion_sort import insertionSort
import math
def bucketSort(alist):
    no_of_bucket = round(math.sqrt(len(alist)))
    max_value= max(alist)
    arr = []

    for i in range(no_of_bucket):
        arr.append([])

    for j in alist:
        index_b = math.ceil(j * no_of_bucket/max_value)
        arr[index_b-1].append(j)

    for i in range(no_of_bucket):
        arr[i] = insertionSort(arr[i])

    k = 0
    for i in range(no_of_bucket):
        for j in range(len(arr[i])):
            alist[k] = arr[i][j]
            k +=1

    print(alist)

if __name__ == "__main__":
    lst = [11,2,3,7,6,8,9]
    bucketSort(lst)