
def partition(alist,low,high):
    i = low -1
    pivot = alist[high]
    for j in range(low,high):
        if alist[j] <= pivot:
            i +=1
            alist[i],alist[j] = alist[j],alist[i]

    alist[i + 1],alist[high] = alist[high],alist[i + 1]
    return (i + 1)
    
def quickSort(alist,low,high):
    if low < high:
        pi = partition(alist,low,high)
        quickSort(alist,low,pi-1)
        quickSort(alist,pi + 1,high)
    

if __name__ == "__main__":
    lst = [11,2,3,7,6,8,9]
    quickSort(lst,0,6)
    print(lst)