# This is a Python program to remove duplicates from a linked list.

# Problem Description
# The program creates a linked list and removes duplicates from it.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define methods append, get_prev_node, remove and display.
# 5. The method append takes a data item as argument and appends a node with that data item to the list.
# 6. The method get_prev_node takes a reference node as argument and returns the previous node. It returns None when the reference node is the first node.
# 7. The method remove takes a node as argument and removes it from the list.
# 8. The method display traverses the list from the first node and prints the data of each node.
# 9. Define a function remove_duplicates which takes a linked list as argument and removes duplicates from it.
# 10. The function remove_duplicates uses two nested loops to remove duplicate nodes.
# 11. Create an instance of LinkedList, remove duplicate nodes and display the list.

class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None


    def append(self,data):
        if self.last_node is None:
            self.head  = Node(data)
            self.last_node = self.head

        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next


    def get_prev_node(self,node):
        current = self.head

        while current and current.next != node:
            current = current.next

        return current

    def remove(self,node):
        prev_node = self.get_prev_node(node)
        if prev_node is None:
            self.head = self.head.next
        else:
            prev_node.next = node.next

    def display(self):
        current = self.head
        while current:
            print(current.data,end=" ")
            current = current.next



def remove_duplicates(llist):
    current1 = llist.head
    while current1:
        data = current1.data
        current2 = current1.next
        while current2:
            if current2.data == data:
                llist.remove(current2)
            current2 = current2.next
        current1 = current1.next


a_llist = LinkedList()
 
data_list = input('Please enter the elements in the linked list: ').split()
for data in data_list:
    a_llist.append(int(data))
 
remove_duplicates(a_llist)
 
print('The list with duplicates removed: ')
a_llist.display()