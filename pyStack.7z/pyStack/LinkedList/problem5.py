# This is a Python program to display the nodes of a linked list in reverse without using recursion.

# Problem Description
# The program creates a linked list using data items input from the user and displays it in reverse.

# Problem Solution
# 1. Create a class Node.
# 2. Create a class LinkedList.
# 3. Define methods append and display inside the class LinkedList to append data and display the linked list respectively.
# 4. Define the method display_reversed.
# 5. display_reversed uses the variable end_node to keep track of the last node that was printed. The variable current then iterates through the list until it reaches the node before end_node. That node is then displayed.
# 6. Create an instance of LinkedList, append data to it and display the list in reverse order.


class Node:
    def __init__(self,data):
        self.data = data 
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None

    def append(self,data):
        if self.last_node is None:
            self.head = Node(data)
            self.last_node =self.head
        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next

    def display_reversed(self):
        

        end_node =None

        while end_node != self.head:
            current = self.head
            while current.next != end_node:
                current = current.next
            print(current.data,end = " ")
            end_node = current

a_llist = LinkedList()
n = int(input('How many elements would you like to add? '))
for i in range(n):
    data = int(input('Enter data item: '))
    a_llist.append(data)
 
print('The reversed linked list: ', end = '')
a_llist.display_reversed()