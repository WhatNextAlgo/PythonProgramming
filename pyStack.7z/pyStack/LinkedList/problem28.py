# This is a Python program to find the union and intersection of two linked lists.

# Problem Description
# The program creates two linked lists and finds their union and intersection.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variable head.
# 3. The variable head points to the first element in the linked list.
# 4. Define methods get_prev_node, duplicate, insert_at_end, remove and display.
# 5. The method get_prev_node takes a reference node as argument and returns the previous node. It returns None when the reference node is the first node.
# 6. The method insert_at_end inserts a node at the last position of the list.
# 7. The method remove takes a node as argument and removes it from the list.
# 8. The method display traverses the list from the first node and prints the data of each node.
# 9. The method duplicate creates a copy of the list and returns it.
# 10. Define the function remove_duplicates which removes duplicate elements from the list passed as argument.
# 11. Define the function find_union which returns the union of the two linked lists passed to it.
# 12. Define the function find_intersection which returns the intersection of the two linked lists passed to it.
# 13. Create two instances of LinkedList, append data to them and find their union and intersection.

class Node:
    def __init__(self,data):
        self.data = data
        self.next =None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None


    def get_prev_node(self,node):
        current = self.head
        while current and current.next != node:
            current = current.next
        return current


    def duplicate(self):
        copy  = LinkedList()
        current = self.head
        while current:
            new = Node(current.data)
            copy.insert_at_end(new)
            current = current.next

        return copy
    
    

    def insert_at_end(self,new_node):
        if self.last_node is None:
            self.head = new_node
            self.last_node = new_node

        else:
            self.last_node.next = new_node
            self.last_node = self.last_node.next
    def append(self,data):

        self.insert_at_end(Node(data))


    def remove(self,node):
        prev_node =self.get_prev_node(node)
        if prev_node is None:
            self.head = node.next
        else:
            prev_node.next = node.next


    def display(self):
        current = self.head
        while current:
            print(current.data, end = ' ')
            current = current.next


def remove_duplicates(alist):
    current1 = alist.head

    while current1:
        data = current1.data
        current2 = current1.next
        while current2:
            if data == current2.data:
                alist.remove(current2)
            current2 = current2.next
        current1 = current1.next


def find_intersection(alist1,alist2):
    if (alist1.head is None or alist2.head is None):
        return LinkedList()

    intersection = LinkedList()
    current1 = alist1.head
    while current1:
        current2 = alist2.head
        data = current1.data
        while current2:
            if data == current2.data:
                new = Node(current2.data)
                intersection.insert_at_end(new)
                break
            current2 = current2.next
        current1 = current1.next
    
    remove_duplicates(intersection)
    return intersection

def find_union(alist1,alist2):
    if alist1.head is None:
        union = alist2.duplicate()
        remove_duplicates(union)
        return union

    if alist2.head is None:
        union = alist1.duplicate()
        remove_duplicates(union)
        return union


    union = alist1.duplicate()
    last_node = union.head
    while last_node.next is not None:
        last_node  = last_node.next

    list2_copy = alist2.duplicate()
    last_node.next = list2_copy.head
    remove_duplicates(union)
    return union



a_llist1 = LinkedList()
a_llist2 = LinkedList()
data_list = input('Please enter the elements in the first linked list: ').split()
for data in data_list:
    node = Node(int(data))
    a_llist1.insert_at_end(node)
data_list = input('Please enter the elements in the second linked list: ').split()
for data in data_list:
    node = Node(int(data))
    a_llist2.insert_at_end(node)
 
union = find_union(a_llist1, a_llist2)
intersection = find_intersection(a_llist1, a_llist2)
 
print('Their union: ')
union.display()
print()
print('Their intersection: ')
intersection.display()
print()