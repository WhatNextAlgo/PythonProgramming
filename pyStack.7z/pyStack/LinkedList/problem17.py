# This is a Python program to add the corresponding elements of two linked lists.

# Problem Description
# The program creates two linked lists using data items input from the user and creates a linked list consisting of the sum of data items of the two lists.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define methods append and display inside the class LinkedList to append data and display the linked list respectively.
# 5. Define a function add_linked_lists which takes two linked lists as arguments.
# 6. The function add_linked_lists returns a linked list which has its elements as the sum of the data items of the two lists passed to it. If one list is shorter, then the rest of the elements are appended from the longer list.
# 7. Create two instances of LinkedList and append data to it.
# 8. Create the sum linked list and display it.
class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None


    def append(self,data):
        if self.last_node is None:
            self.head  = Node(data)
            self.last_node = self.head

        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next

    def display(self):
        current= self.head

        while current:
            print(current.data, end =" ")
            current = current.next


def add_linked_lists(list1,list2):
    sum_list = LinkedList()
    current1 = list1.head
    current2 = list2.head
    while current1 and current2:
        sum = current1.data + current2.data
        sum_list.append(sum)
        current1 = current1.next
        current2 = current2.next

    if current1 is None:
        while current2:
            sum_list.append(current2.data)
            current2 = current2.next
    
    if current2 is None:
        while current1:
            sum_list.append(current1.data)
            current1 = current1.next

    return sum_list


llist1 = LinkedList()
llist2 = LinkedList()
 
data_list = input('Please enter the elements in the first linked list: ').split()
for data in data_list:
    llist1.append(int(data))
 
data_list = input('Please enter the elements in the second linked list: ').split()
for data in data_list:
    llist2.append(int(data))
 
sum_llist = add_linked_lists(llist1, llist2)
 
print('The sum linked list: ', end = '')
sum_llist.display()
