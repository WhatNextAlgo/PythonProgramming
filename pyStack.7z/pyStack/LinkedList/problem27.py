# This is a Python program to convert a given singly linked list to a circular list.

# Problem Description
# The program creates a singly linked list and converts it into a circular list.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the single linked list while last_node points to the last.
# 4. Define method append to append data items to the list.
# 5. Define function convert_to_circular which takes a singly linked list as argument.
# 6. The function convert_to_circular converts the list passed into a circular list by making the last node point to the first.
# 7. Define function print_last_node_points_to to display what the last node of the passed linked list points to.
# 8. Create an instance of LinkedList, append data to it and convert it to a circular list.

class Node:
    def __init__(self,data):
        self.data = data
        self.next =None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None
    

    def insert_at_end(self,new_node):
        if self.last_node is None:
            self.head = new_node
            self.last_node = new_node

        else:
            self.last_node.next = new_node
            self.last_node = self.last_node.next
    def append(self,data):

        self.insert_at_end(Node(data))


    def display(self):
        current = self.head
        while current:
            print(current.data, end = ' ')
            current = current.next


def convert_to_circular(alist):
    if alist.last_node:
        alist.last_node.next = alist.head   


def print_last_node_points_to(alist):
    last = alist.last_node

    if last is None:
        print('List is empty.')
        return
    if last.next is None:
        print('Last node points to None.')

    else:
        print('Last node points to element with data {}.'.format(last.next.data))



a_llist = LinkedList()
 
data_list = input('Please enter the elements in the linked list: ').split()
for data in data_list:
    a_llist.append(int(data))
 
print_last_node_points_to(a_llist)
 
print('Converting linked list to a circular linked list...')
convert_to_circular(a_llist)
 
print_last_node_points_to(a_llist)