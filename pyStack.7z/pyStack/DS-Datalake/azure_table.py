"""
author: Harish Ganesh
"""
from datetime import datetime

from azure.cosmosdb.table.models import Entity
from azure.cosmosdb.table.tableservice import TableService

# import db_config


class IContext:
    """ A context manager to automatically close an object with a close method
    in a with statement. """

    def __init__(self, obj):
        self.obj = obj

    def __enter__(self):
        # bound to target
        return self.obj

    def __exit__(self, exception_type, exception_val, trace):
        self = None


def insert(PartitionKey, DataSource, Frequency, PricingStatus, ForecastingStatus, exception):
    """
    insert the log entry into azure table
    :param PartitionKey: id
    :param DataSource: data source
    :param Frequency: frequency of prices
    :param PricingStatus: sql status
    :param ForecastingStatus: forecast status
    :param exception:
    :return:
    """
    log_entity = Entity()
    log_entity.PartitionKey = PartitionKey
    log_entity.RowKey = str(datetime.now())
    log_entity.DataSource = DataSource
    log_entity.Frequency = Frequency
    log_entity.PricingStatus = PricingStatus
    log_entity.ForecastingStatus = ForecastingStatus
    log_entity.Exception = exception
    # with IContext(TableService(account_name=db_config.settings['ACCOUNT_NAME'], account_key=db_config.settings['ACCOUNT_KEY'])) as table_service:
    #     table_service.insert_or_replace_entity('CommodityPricingLogs', log_entity)
