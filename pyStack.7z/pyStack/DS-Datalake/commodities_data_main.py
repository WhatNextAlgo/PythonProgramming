
"""
author: Harish Ganesh
"""

import sys

# from data_reader.bls_daily_load import BLS_daily
# from data_reader.eia import eia
# from data_reader.eurostat_daily_load import eurostat_daily
from fred_daily_load import *
from bls_daily_load import *

if __name__ == '__main__':
    source = sys.argv[1]
    bpc = sys.argv[2]
    region_id = sys.argv[3]

    data_pull_methods = {'fred': fred_daily,'bls': BLS_daily}
    # , 'eurostat': eurostat_daily, 'bls': BLS_daily, 'eia': eia}
    assert source in data_pull_methods.keys(), 'unknown data source given as argument'
    data_pull_methods[source](bpc, region_id)


