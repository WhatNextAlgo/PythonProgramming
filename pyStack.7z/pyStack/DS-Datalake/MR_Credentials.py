from azure.keyvault import *
from azure.common.credentials import ServicePrincipalCredentials
# from config import TENANT_ID, KEY_VAULT_CLIENT_ID, KEY_VAULT_RESOURCE, KEY_VAULT_SECRET,SECRET_NAME, SECRET_VERSION
from datetime import datetime

def get_multiregion_credentials():
    """
        gets the multiregion credentials from azure key vault
    :return: server name, database name, user id,password
    """
    KEY_VAULT_RESOURCE="https://dev-common-appkvault.vault.azure.net/"
    KEY_VAULT_CLIENT_ID="0b39a62c-4a17-4309-a2e6-6f30a06add70"
    TENANT_ID="e3a291d3-8a20-4c35-8d08-38ffcafa479d"
    KEY_VAULT_SECRET="TT?MW[:lnV[voOQ01gCQok7OjcN2FVpO"
    SECRET_NAME="MRConfigSqlConn"
    SECRET_VERSION="b5567c3370464d0e8c09a12265e6c2ab"
    try:
        credentials = ServicePrincipalCredentials(
            client_id=KEY_VAULT_CLIENT_ID,
            secret=KEY_VAULT_SECRET,
            tenant=TENANT_ID
        )
        key_name=[]
        value=[]
        client = KeyVaultClient(credentials)
        secret_bundle = client.get_secret(KEY_VAULT_RESOURCE, SECRET_NAME, SECRET_VERSION)
        print('MultiRegionConfig secret received from Keyvault at {}'.format(str(datetime.now())))
        secret = secret_bundle.value
        secret = secret.split(";")
        for values in secret:
            try:
                key_name.append(values.split("=")[0])
                value.append(values.split("=")[1])
            except:
                pass

        server = value[0]
        database = value[1]
        user = ""
        password = ""
        for i in range(len(key_name)):
            if key_name[i].lower() == 'user id':
                user = value[i]
            elif key_name[i].lower() == 'password':
                password = value[i]
        print('MultiRegionConfig secret processed at {}'.format(str(datetime.now())))
        return server, database, user, password
    except Exception as e:
        print('Error in get_multiregion_credentials. {}'.format(str(e)))
        raise e
