# Input Variable setup
##############################################################################################################
######################         This code reads the data from EXTERNALSOURCES.CSV file , reads fred info ######
######################              and finally populates Commodity Master table #############################


import csv
from pyspark.sql import SparkSession
from pprint import pprint
import config
from pyspark.sql import SparkSession
import MR_Credentials
import multi_region_config_script
from input_config import *

mrObj=multi_region_config_script.get_multiregion_object()
buyer_server, buyer_database, buyer_username, buyer_password = mrObj.get_buyer_db_connectionstring("70021790", 17)
# print(buyer_server)
buyer_server="tcp:hx67tx2ygu.database.windows.net,1433"
buyer_database="Dev_Datalake"
buyer_username="gep_sql_admin"
buyer_password="Password@123"
fred_datapath="/FileStore/tables/"

# #Setting spark conf
spark = SparkSession.builder.getOrCreate()
spark.conf.set("fs.azure.account.key.scmdevdpdatalake.dfs.core.windows.net", "xy+w+9tLBMRso0+DQQjnHSDX4KE8CPZmM6oIUSsAenef3IK5rsa7nm1Gk4UDS6sIVE/dEQe1hLMk6YTIEsEnGQ==")


connectionProperties={'user' : buyer_username,'password':buyer_password,'driver':'com.microsoft.sqlserver.jdbc.SQLServerDriver'}
dburl="jdbc:sqlserver://"+buyer_server.split(':')[1].replace(',',':')+";database="+buyer_database+";"
   

def readFile(fileName):
  return spark.read.option("header","true").option("inferschema","true").csv(fileName)


externalSourcesDF=readFile(settings.get('MANUAL_PETRONAS_DATA_PATH')).filter("Source!='IHS Markit'").drop("Id")
externalSourcesDF.createOrReplaceTempView("metadata")
externalSourcesDF.show()
# externalSourcesDF.write.jdbc("jdbc:sqlserver://hx67tx2ygu.database.windows.net:1433;database=Test_datalake","ds_CommodityMaster",'append',connectionProperties)

commodityDF=spark.sql("select concat(Commodity,'-',CategoryLevel1,'-',region) as SeriesId,Commodity,explode(split(CategoryLevel1,'//')) as CategoryLevel1,CategoryLevel2,Region,Country,State,City,Title,Source,Release,UnitOfMeasure,ChartTitle,YAxisTitle,Frequency,SeasonalAdjustment,ObservationStartDate,ObservationEndDate,LastUpdatedDate,Industry,Website,PriceAdjustment from metadata")

# dfNew.show()

commodityDF.write.jdbc(dburl,"ds_CommodityMaster",'append',connectionProperties)
# print("Data written to sql server")

