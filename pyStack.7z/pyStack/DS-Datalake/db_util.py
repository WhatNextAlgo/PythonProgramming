"""
author: Harish Ganesh
"""
import pyodbc
import os
import input_config
import multi_region_config_script as ms
# from pyspark.sql.types import *
from pyspark.sql.functions import lit
# from pyspark.sql import SparkSession

config_object = ms.get_multiregion_object()

def get_connection_string(bpc, region_id):
    server, database, uid, pwd = config_object.get_buyer_db_connectionstring(bpc, region_id)
    connection = "server:" + server +" database:"+ database + " uid:"+ uid + " pwd:"+ pwd
    print(connection)
    return (server,database,uid,pwd)


# def create_connection_config():
#     cnxn = pyodbc.connect(
#         'DRIVER={ODBC Driver 17 for SQL Server}' +
#         ';SERVER=' +
#         db_config.settings['SERVER'] +
#         ';PORT=1433;DATABASE=' +
#         db_config.settings['DATABASE'] +
#         ';UID=' +
#         db_config.settings['USERNAME'] +
#         ';PWD=' +
#         db_config.settings['PASSWORD'])
#     cursor = cnxn.cursor()
#     return (cnxn, cursor)


def create_connection(buyer_server,buyer_database,buyer_username,buyer_password):
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server}' +
                          ';SERVER=' +
                          buyer_server +
                          ';PORT=1433;DATABASE=' +
                          buyer_database +
                          ';UID=' +
                          buyer_username +
                          ';PWD=' +
                          buyer_password)
    cursor = cnxn.cursor()
    return (cnxn, cursor)


def write_to_sql(spark,file_name, server, database, uid, pwd ):
    print("in write_to_sql")
    finalDF=spark.read.format("csv").option("header","true").load(file_name)
    # df.show()
    finalDF= finalDF.withColumnRenamed("date","Date")
    finalDF= finalDF.withColumnRenamed("value","Price")
    finalDF= finalDF.withColumnRenamed("series_id","SeriesID")
    # finalDF.createOrReplaceTempView(tabl"eName)
    connectionProperties={'user' : uid,'password':pwd,'driver':'com.microsoft.sqlserver.jdbc.SQLServerDriver'}
    dburl="jdbc:sqlserver://"+server.split(':')[1].replace(',',':')+";database="+database+";"
    finalDF.write.jdbc(dburl,"ds_stg_CommodityPriceDetails",'append',connectionProperties)
    # print(dburl)
    finalOutLocation=input_config.settings.get('datalake_path')
    # to be replaced with blob code
    # finalDF.write.format('com.databricks.spark.csv').mode('overwrite').option("header", "true").save(finalOutLocation)
    # print("Data written to dev stg CM")
    # command ='/opt/mssql-tools/bin/bcp "dbo.ds_STG_CommodityPriceDetails" in {} -S {} -d {} -F2 -c -t"," -U {} -P {} -e error.txt'.format(file_name,server,database,uid,pwd)
    # os.system(command)
    return 'success'


def write_to_main_sql_table(series_id,cnxn,cursor):
    print("in write_to_main_sql_table")
    sql ="""insert into dbo.ds_commoditypricedetails
(
  [ID]
  , [Price_Date]
  , [Price]
)
select 
  b.id
  , a.date
  , a.price 
from 
  dbo.ds_stg_commoditypricedetails  as  a  with(nolock)
inner join
  dbo.ds_commoditymaster        as  b   with(nolock)
on 
  a.seriesid = b.seriesid 
where 
    a.seriesid='{}'
and
  not exists
  (
    select 
      1
    from 
      dbo.ds_commoditypricedetails as c with(nolock)
    where
      b.id = c.id
    and 
      a.date = c.price_date
  ) """.format(series_id)
    cursor.execute(sql)
    cnxn.commit()


def del_stg_table(series_id, cursor, cnxn):
    sql ="delete from ds_stg_commoditypricedetails where seriesid='{}'".format(series_id)
    cursor.execute(sql)
    cnxn.commit()