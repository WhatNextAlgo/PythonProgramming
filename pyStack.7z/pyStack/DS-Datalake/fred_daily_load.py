"""
author: Harish Ganesh
Modification : Sandhya Harane 03/18
"""

import time
import pandas as pd
# from azure.storage.blob.blockblobservice import BlockBlobService
from fred import Fred
#import db_config
import azure_table
from helper import *
import MR_Credentials
import multi_region_config_script
import db_util
import math
# blob_service = BlockBlobService(
#     account_name=db_config.settings['ACCOUNT_NAME'],
#     account_key=db_config.settings['ACCOUNT_KEY'])

# blob_service = BlockBlobService(
#     account_name="scmdevdpdatalake",
#     account_key="xy+w+9tLBMRso0+DQQjnHSDX4KE8CPZmM6oIUSsAenef3IK5rsa7nm1Gk4UDS6sIVE/dEQe1hLMk6YTIEsEnGQ==")

# fr = Fred(api_key=db_config.settings['API_KEY'], response_type='df')
fr = Fred(api_key='f9d93f630e86671a33dfd32b5e36bef7',response_type='df')

blob_dir_name = time.strftime("%Y%m%d")


def download_file(series_id_master, series_id):
    """
        This function download data for a series and save the data in a csv format in specified directory
        :param series_id
        :return:
        """
    print("in download_file")
    print(series_id)
    data = fr.series.observations(series_id)
    print("data is")
    # print(data)
    data.drop(['realtime_start', 'realtime_end'], axis=1, inplace=True)
    data.dropna(inplace=True)
    data.insert(0, "series_id", series_id_master, False)
    data.dropna(inplace=True)
    data["value"] = data["value"].apply(lambda x: float(x))
    data["value"] = data["value"].apply(lambda x: round(x, 4))
    # print(data["value"])
    file_name = series_id + '.csv'
    #data = data.tail(10)
    # data.to_csv("../sampleSeries.csv", index=False)

    print("Data is writing at ")
    print(file_name)
    print(input_config.settings.get('fred_datapath'))
    # data.to_csv('/dbfs'+input_config.settings.get('fred_datapath')+file_name, index=False)
    data.to_csv("C:/Users/sandhya.harane/OneDrive - GEP/Mi-Data-New/"+file_name, index=False)
    print("Data is written at " +"C:/Userssandhya.harane/OneDrive - GEP/Mi-Data"+file_name)
    return file_name


# def write_to_blob(file_name):
#     print("in write_to_blob")
#     container_name = "datalake"
#     full_path_file_name = "/dbfs/FileStore/tables/IPBUSEQ.csv"
#     # print("full_path_file_name")
#     # print(full_path_file_name)
#     file_name = 'IPBUSEQ.csv'
#     # print("file_name")
#     # print(file_name)
#     print("Eriting data to blob")
#     blob_service.create_blob_from_path(container_name, file_name, full_path_file_name)
#     print("File written to blob,")


def get_series_id(cnxn):
    sql = """select id, seriesid, frequency from dbo.ds_CommodityMaster where website='fred' and seriesid='IPBUSEQ';"""
    return cnxn.execute(sql)


def fred_daily(bpc, reg_id):
    mrObj=multi_region_config_script.get_multiregion_object()
    buyer_server, buyer_database, buyer_username, buyer_password = mrObj.get_buyer_db_connectionstring(bpc, reg_id)
    buyer_server="tcp:hx67tx2ygu.database.windows.net,1433"
    buyer_database="Dev_Datalake"
    buyer_username="gep_sql_admin"
    buyer_password="Password@123"
    fred_datapath=input_config.settings.get('fred_datapath')
    cnxn, cursor =db_util.create_connection(buyer_server, buyer_database, buyer_username, buyer_password)
    result = get_series_id(cnxn)
    df = pd.DataFrame(result.fetchall())

    for row in df.itertuples():
        actual_series_id = row[1][1]
        formatted_series_id = actual_series_id.split('/')[0]
        print("actual_series_id")
        print(actual_series_id)

        print("formatted_series_id")
        print(formatted_series_id)
        # download the data
        try:
            file_name = download_file(actual_series_id, formatted_series_id)
            # write_to_blob(file_name)
            download_status = 'success'
        except (ValueError, OSError) as e:
            download_status = 'failure'
            sql_status = 'failure'
            forecast_status = 'failure'
            exception = e

        # uploading data to sql
        if download_status == 'success':
            
            sql_status, exception = load_prices_to_db(actual_series_id, fred_datapath+file_name, cnxn, cursor,
                                                      buyer_server, buyer_database,
                                                      buyer_username,
                                                      buyer_password)

        # # forecast
        # if sql_status == 'success':
        #     forecast_status, exception = do_forecast(actual_series_id, cnxn, cursor, buyer_server, buyer_database,
        #                                              buyer_username,
        #                                              buyer_password)

        # log the status in az table
        try:
            azure_table.insert(str(row[1][0]), "Fred", str(row[1][2]), sql_status,
                               forecast_status, str(exception))
        except BaseException:
            print("insertion into azure table failed for id = {}".format(row[1][1]))
