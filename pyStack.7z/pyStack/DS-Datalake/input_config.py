settings = {
    'MANUAL_PETRONAS_DATA_PATH': '/FileStore/tables/CommodityMeta_Latest.csv',
    'fred_datapath': '/FileStore/tables/',
    'bls_datapath': '',
    'datalake_key': 'xy+w+9tLBMRso0+DQQjnHSDX4KE8CPZmM6oIUSsAenef3IK5rsa7nm1Gk4UDS6sIVE/dEQe1hLMk6YTIEsEnGQ==',
    'datalake_path': 'abfss://datalake@scmdevdpdatalake.dfs.core.windows.net/users/sandhya/MILATEST',
    'CSV_PATH_PROCESSED': 'Client_CSV_Processed/',
    'DIR_PROCESSED_NAME': 'Client_CSV_Processed',
    'CHUNK_SIZE': 5000,
    'SERVER':  '',
    'DATABASE':  'Dev_Oge',
    'USERNAME':  '',
    'PASSWORD':  '',
    'DRIVER': '{ODBC Driver 17 for SQL Server}',
    'API_KEY':''
}