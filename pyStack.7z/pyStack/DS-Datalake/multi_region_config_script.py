"""
Author: Manas Goth
"""
import re
import os
import pyodbc
import MR_Credentials as mr
from datetime import datetime

def get_multiregion_object():
    MR_creds = mr.get_multiregion_credentials()
    print('MultiRegionConfig credentials received at {}'.format(str(datetime.now())))
    config_object = multiregion()
    config_object.MR_SERVER = MR_creds[0]
    config_object.MR_DATABASE = MR_creds[1]
    config_object.MR_USERNAME = MR_creds[2]
    config_object.MR_PASSWORD = MR_creds[3]
    config_object.execute_multiregion_query()
    return config_object


class multiregion():
    """
    Connects to SMART "MultiRegionConfig" database.
    Executes [dbo].[usp_CFG_GetMultiRegionConfiguration] stored procedure.
    Stores the output of the stored procedure( 2 tables) into  _multi_region_global_settings.
    For a Config Key, returns the Config key Value.
    """
    MR_SERVER = ""
    MR_DATABASE = ""
    MR_USERNAME = ""
    MR_PASSWORD = ""

    def __init__(self):
        self._multi_region_global_settings = {}

    def get_connection_string(self, key):
        print("in get_connection_string")
        """
        To retrieve the ConfigKeyValue always use this function.
        Never consume the _multi_region_global_settings directly . (Due to Security reasons)
        For a ConfigKey , returns the ConfigKeyValue
        :param key: string, config key
        :return:string, config key value
        """
        connection_string = ""
        try:
            connection_string = self._multi_region_global_settings[key]
            print("connection_string")
            print(connection_string)
        except KeyError:
            connection_string = "No connection string was found for this key"
        return connection_string

    def get_multiregion_connection(self):
        """
        Reads the connection details for MultiRegionConfig from the App settings.
        Establishes a connection to MultiRegionConfig and returns the connection string.
        :return: string
        """
        # server = os.environ["multi_region_server"]
        # database = os.environ["multi_region_database"]
        # username = os.environ["multi_region_username"]
        # password = os.environ["multi_region_password"]
        cnxn_str = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + \
                   self.MR_SERVER + \
            ';DATABASE=' + \
                   self.MR_DATABASE + \
            ';UID=' + \
                   self.MR_USERNAME + \
            ';PWD=' + \
                   self.MR_PASSWORD
        cnxn = pyodbc.connect(cnxn_str)

        cursor = cnxn.cursor()
        return cursor

    def execute_multiregion_query(self):
        """
        Executes the stored procedure.
        Converts the SQL table output into json.
        Modifies the __multi_region_global_settings json.
        :return:None
        """
        connection = self.get_multiregion_connection()
        query = "[dbo].[usp_CFG_GetMultiRegionConfiguration]"
        connection.execute(query)
        print('usp_CFG_GetMultiRegionConfiguration query execution at {}'.format(str(datetime.now())))
        # process the first table here
        row = connection.fetchone()
        while row:
            self._multi_region_global_settings[row[0]] = row[1]
            row = connection.fetchone()
        # process second table onwards here
        while connection.nextset():
            row = connection.fetchone()
            while row:
                self._multi_region_global_settings[row[0]] = row[1]
                row = connection.fetchone()
        print('usp_CFG_GetMultiRegionConfiguration query processed at {}'.format(str(datetime.now())))

    def get_smartconfiguration_configsqlconn(self, bpc, region_id):
        """
        Will get the smart_configuration for the environment
        :param bpc: string, Buyer partner Code for the user
        :param region_id:string, region of the buyer domain
        :return:
        """
        smart_config_db_address = ""
        server = ""
        database = ""
        user_id = ""
        password = ""
        config_key = str(bpc) + '~' + 'ConfigSqlConn' + '~' + str(region_id)
        default_config_key = 'ConfigSqlConn'
        d = self._multi_region_global_settings
        if d.get(config_key):
            smart_config_db_address = d.get(config_key)
        else:
            smart_config_db_address = d.get(default_config_key)
        server, database, user_id, password = self.get_smartconfiguration_credentials(smart_config_db_address)
        return server, database, user_id, password

    def get_smartconfiguration_credentials(self, smart_config_db_address):
        """
        Given a ConfigSqlConn , extracts the Server, Database, User ID, Password
        :param smart_config_db_address:string, the connection string
        :return:string, Server, Database, User ID, Password
        """
        server = ""
        database = ""
        user_id = ""
        password = ""
        data_list = smart_config_db_address.split(sep=';')
        for i in data_list:
            if 'Server=' in i or 'Data Source=' in i:
                server = re.sub('Server=', "", i)
                server = re.sub('Data Source=', "", server)
            if 'Database=' in i or 'Initial Catalog=' in i:
                database = re.sub('Database=', "", i)
                database = re.sub('Initial Catalog=', "", database)
            if 'User ID=' in i or 'User Id=' in i:
                user_id = re.sub('User ID=', "", i)
                user_id = re.sub('User Id=', "", user_id)
            if 'Password=' in i:
                password = re.sub('Password=', "", i)
        return server, database, user_id, password

    def get_buyer_db_connectionstring(self, bpc, region_id):
        """
        Will get the Smart configuration connection string.
        Connect to Smart configurations ,derive the buyer db connection details from PRN_PartnerDBConfiguration
        :param bpc: string,
        :param region_id: string,
        :return:strings, buyer_server, buyer_database, buyer_username, buyer_password
        """
        sc_server = ""
        sc_database = ""
        sc_uid = ""
        sc_pwd = ""
        smartconfig_connectionstring = ""
        buyer_server = ""
        buyer_database = ""
        buyer_username = ""
        buyer_password = ""
        sc_server, sc_database, sc_uid, sc_pwd = self.get_smartconfiguration_configsqlconn(bpc, region_id)
        print('Smart Config credentials have been created at {}'.format(str(datetime.now())))
        connection = self.smart_configuration_connection(sc_server, sc_database, sc_uid, sc_pwd)
        print('Smart Config connection object has been created at {}'.format(str(datetime.now())))
        smartconfig_connectionstring = self.execute_smartconfig_query(bpc, region_id, connection)
        print('Smart Config query has been executed at {}'.format(str(datetime.now())))
        buyer_server, buyer_database, buyer_username, buyer_password = self.get_buyer_credentials(
            smartconfig_connectionstring)
        return buyer_server, buyer_database, buyer_username, buyer_password

    def smart_configuration_connection(self, server, database, username, password):
        """
                Establishes a connection to SmartConfiguration and returns the connection string.
                :return: string, the connection string
                """
        cnxn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' +
            server +
            ';DATABASE=' +
            database +
            ';UID=' +
            username +
            ';PWD=' +
            password)
        cursor = cnxn.cursor()
        return cursor

    def execute_smartconfig_query(self, bpc, region_id, connection):
        """
        Execute the query on PRN_PartnerDBConfiguration
        :return:string, Returns the buyer db connection string
        """
        connection_position = 0
        buyer_db_connection_string = ""
        # connection = self.smart_configuration_connection()
        query = """ SELECT * from  PRN_PartnerDBConfiguration
                    WHERE PartnerCode =
                """ + str(bpc) + """ AND DBType = 'OLTP' """
        connection.execute(query)
        # process the records returned
        row = connection.fetchone()
        for k in connection.columns(table='PRN_PartnerDBConfiguration'):
            if k.column_name == 'ConnectionString':
                break
            else:
                connection_position = connection_position + 1
        if connection_position < len(row):
            buyer_db_connection_string = (row[connection_position])
        return buyer_db_connection_string


    def get_buyer_credentials(self, buyer_connection_string):
        """
        Given a buyerConnectionString , extracts the Server, Database, User ID, Password
        :param buyer_connection_string:string, the buyer connection string
        :return:string, Server, Database, User ID, Password
        """
        server = ""
        database = ""
        user_id = ""
        password = ""
        data_list = buyer_connection_string.split(sep=';')
        for i in data_list:
            if 'Data Source=' in i:
                server = re.sub('Data Source=', "", i)
            if 'Initial Catalog=' in i:
                database = re.sub('Initial Catalog=', "", i)
            if 'User Id=' in i:
                user_id = re.sub('User Id=', "", i)
            if 'Password=' in i:
                password = re.sub('Password=', "", i)
        return server, database, user_id, password
