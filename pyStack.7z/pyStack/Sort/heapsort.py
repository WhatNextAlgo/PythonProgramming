def heapify(arr,n,i):
    print(arr[i],"largest index")
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2

    #check if left element is largest w.r.t parent node
    if left < n and arr[left] > arr[i]:
        largest = left
    
    #check if right  element is largest w.r.t (parent/left)
    if right < n and arr[right] > arr[largest]:
        largest = right
    
    if largest != i:
        arr[largest], arr[i] = arr[i], arr[largest]
        heapify(arr,n,largest)


def heapSort(arr):
    n = len(arr)
    #In the case of a complete tree, the first index of a non-leaf node is given by n/2 - 1.
    #All other nodes after that are leaf-nodes and thus don't need to be heapified.
    for i in range(n//2 -1,-1,-1):
        heapify(arr,n,i)

    for i in range(n-1,0,-1):
        arr[i],arr[0]= arr[0],arr[i]
        heapify(arr,i,0)


arr = [1, 12, 9, 5, 6, 10,15,14]
heapSort(arr)
n = len(arr)
print("Sorted array is")
for i in range(n):
    print("%d " % arr[i], end='')


