lst = [1,2,3,4,6,7,8,9,10]
print(lst)

#Missing Number
def findMissing(alist,n):
    #
    sum1 = n* (n +1)/2
    sum2 = sum(alist)

    print(sum1-sum2)

findMissing(lst,10)

#Find all pairs in array of integer when sum is equal to given number

def findAllPairs(alist,sum):
    for i in range(len(alist)):
        for j in range(len(alist)):
            if (alist[i]+ alist[j]) == sum:
                print(alist[i],alist[j])

findAllPairs(lst,5)

#how to check if an array contains a number in python

import numpy as np 
my_array = np.array([1,2,3,50,5,61,7,8,9,10])

def findNumber(alist,n):
    for x in range(len(alist)):
        if alist[x] == n:
            print(alist[x])

findNumber(my_array,5)


#how to find maximum product of two integer in the given array where all element are postive.

def findmaxproduct(alist):
    max_val_so_far = 0

    for x in range(len(alist)-1):

        val = alist[x] * alist[x+1]
        

        if val > max_val_so_far:
            max_val_so_far = val
            pairs = f"{alist[x]},{alist[x+1]}"

    print(max_val_so_far)
    print(pairs)

findmaxproduct(my_array)
    

def isUnique(alist):
    lst = []

    for x in alist:
        if x in lst:
            print(x,"repeated")
            return False
        else:
            lst.append(x)
    return True

isUnique([1,2,3,4,4,5,6])

#permutation

def ispermutation(alist1,alist2):
    alist2.reverse()
    return alist1 == alist2

print(ispermutation([1,2,3],[3,2,1]))

td_array = np.array([[1,2,3],[4,5,6],[7,8,9]])
print(td_array)

def rotate_matrix(td_array):
    n = len(td_array)

    for layer in range(n//2):
        first = layer
        last = n - layer - 1
        for i in range(first,last):
            # save top
            top = td_array[layer][i]
            #move left elem to top
            td_array[layer][i] = td_array[-i-1][layer]
            #move bottom elm to left
            td_array[-i-1][layer] = td_array[-layer-1][-i-1]
            #move right to bottom
            td_array[-layer-1][-i-1] = td_array[i][-layer-1]
            #move top to right 
            td_array[i][-layer-1] = top


    print(td_array)

rotate_matrix(td_array)