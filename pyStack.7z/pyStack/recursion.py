def factorial(n):
    assert n >= 0  and int(n) == n, 'The number must be positive integer only!'
    if n in [0,1]:
        return 1
    else:
        return n * factorial(n-1)

#print(factorial(1))

def fibonaci(n):
    assert n >= 0  and int(n) == n, 'Fibonacci number cannot be negative number or non Integer.'

    if n in [0,1]:
        return n
    else:
        return fibonaci(n-1) + fibonaci(n-2)

#print(fibonaci(7))

def SumOfDigit(n):
    assert n >= 0  and int(n) == n, 'The number must be positive integer only!'
    if n == 0:
        return 0
    return int(n%10) + SumOfDigit(int(n/10))

#print(SumOfDigit(112))

#Calculates power of a number using Recursion

def powerofNumber(base,exp):
    assert exp >=0 and int(exp)==exp, 'exponent must be positive integer only!'
    if exp == 0:
        return 1
    if exp == 1:
        return base
    else:
        return base * powerofNumber(base,exp-1)
    
#print(powerofNumber(2,4))

def gcd(a,b):
    assert int(a) == a and int(b) == b, 'The number must be integer only!'
    if a < 0:
        a = -1 * a
    if b < 0:
        b = -1 * b


    if b == 0:
        return a
    return gcd(b, a % b)

#print(gcd(48,1.8))

def convert_dec_to_bin(num):
    assert int(num) == num, 'The number must be Integer Only!'
    if num == 0:
        return 0

    return num%2 + 10 * convert_dec_to_bin(int(num/2))

print(convert_dec_to_bin(10))

