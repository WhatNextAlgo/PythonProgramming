def smart_divide(func):

    def inner(a,b):
        print(f"Divide {a} by {b}")
        if b == 0:
            print("Whoops! cannot divide")
        return func(a,b)

    return inner
        
@smart_divide
def divide(a, b):
    return a / b



#print(divide(10,2))


def star(func):

    def inner(*args,**kargs):
        print("*" * 30)
        func(*args,**kargs)
        print("*" * 30)

    return inner

def percent(func):
    
    def inner(*args,**kargs):
        print("%" * 30)
        func(*args,**kargs)
        print("%" * 30)

    return inner


@star
@percent
def printer(*msg,**kmsg):
    for p in msg:
        print(p)
    

    for p in kmsg:
        print(f"{p} : {kmsg[p]}")

    print()

#printer(sumit = "Hello",mike ="Hi",)

#Class decorator
class decorator_class:
    def __init__(self,original_function):
        self.original_function = original_function


    def __call__(self,*args,**kargs):
        print("Call Method executed this before {} function".format(self.original_function.__name__))
        return self.original_function(*args,**kargs) 

#Function Decorator
def decorator_fucntion(original_function):

    def wrapper_function(*args,**kargs):
        print("wrapper executed this before {} function".format(original_function.__name__))
        return original_function(*args,**kargs)

    return wrapper_function

from functools import wraps

##Practical UseCase 
def my_logger(orig_func):
    import logging
    logging.basicConfig(filename="{}.log".format(orig_func.__name__),level=logging.INFO)
    
    @wraps(orig_func)
    def wrapper(*args,**kargs):
        logging.info(
            "Ran with args = {} and kargs = {}".format(args,kargs)
        )
        return orig_func(*args,*kargs)

    return wrapper

def my_timer(orig_func):
    import time
    
    @wraps(orig_func)
    def wrapper(*args,**kargs):
        t1 = time.time()
        result = orig_func(*args,**kargs)
        t2 = time.time() -t1
        print("{} ran in: {} sec.".format(orig_func.__name__,t2))
        return result
    return wrapper


@decorator_fucntion
def display():
    print("display function ran!")


@my_logger
@my_timer
def display_info(name,age):
    print("display_info function ran  with argument ({},{})".format(name,age))


#decorator_display = decorator_fucntion(display)
#decorator_display()

# above code is equivalent to below code when we mark display function as @decorator_fucntion
#display()
display_info("Sumit",27)

