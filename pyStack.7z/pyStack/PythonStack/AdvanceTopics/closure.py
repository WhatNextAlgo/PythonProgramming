def make_multiplie_of(n):
    def multipler(x):
        return x * n
    return multipler


times3 = make_multiplie_of(3)
print(times3(9))
print(times3.__closure__)
print(times3.__closure__[0].cell_contents)