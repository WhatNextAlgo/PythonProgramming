import os
import configparser
config = configparser.SafeConfigParser()
config.read('api.ini')
print(config.keys)
KEY_VAULT_CLIENT_ID = config['KEY_VAULT_CLIENT_ID']['val']
KEY_VAULT_RESOURCE = config['KEY_VAULT_RESOURCE']['val']
KEY_VAULT_SECRET = config['KEY_VAULT_SECRET']['val']
TENANT_ID = config['TENANT_ID']['val']
SECRET_NAME = config['SECRET_NAME']['val']
SECRET_VERSION = config['SECRET_VERSION']['val']
