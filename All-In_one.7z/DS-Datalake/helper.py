# from api.cmd_forecast import test_fit_predict_refreshed_data
from db_util import *
# from . import eurostat_datapath, fred_datapath, BLS_datapath, pjoin, remove
# from . import  fred_datapath,pjoin, remove
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
import input_config
def load_prices_to_db(actual_series_id, file_path, cnxn, cursor, buyer_server, buyer_database, buyer_username,
               buyer_password):
    """

    :param actual_series_id:
    :param file_path:
    :param cnxn:
    :param cursor:
    :param buyer_server:
    :param buyer_database:
    :param buyer_username:
    :param buyer_password:
    :return:
    """
    exception = ''
    try:
        spark = SparkSession.builder.getOrCreate()
        spark.conf.set("fs.azure.account.key.scmdevdpdatalake.dfs.core.windows.net", input_config.settings.get('datalake_key'))
        write_to_sql(spark,file_path, buyer_server, buyer_database, buyer_username, buyer_password)
        remove(file_path)
        dbutils = DBUtils(spark)
        print("Putting file to datalake")
        print("Removing dbfs temperory file.")
        dbutils.fs.rm(file_path)
        write_to_main_sql_table(actual_series_id, cnxn, cursor)
        del_stg_table(actual_series_id, cursor, cnxn)
        sql_status = 'success'
    except pyodbc.Error:
        try:
            cnxn, cursor = create_connection(buyer_server, buyer_database, buyer_username, buyer_password)
            write_to_main_sql_table(actual_series_id, cnxn, cursor)
            del_stg_table(actual_series_id, cursor, cnxn)
            sql_status = 'success'
        except pyodbc.Error as e:
            sql_status = 'failure'
            exception = e
    print("in load_prices_to_db")
    print("sql_status")
    print(sql_status)
    print("exception")
    print(exception)
    return sql_status, exception


# def do_forecast(actual_series_id, cnxn, cursor, buyer_server, buyer_database, buyer_username, buyer_password):
#     print("in start do_forecast")
#     exception = ''
#     try:
#         test_fit_predict_refreshed_data(actual_series_id, cnxn, cursor)
#         forecast_status = 'success'
#     except ValueError as e:
#         forecast_status = 'failure'
#         exception = e
#     except pyodbc.Error:
#         try:
#             cnxn, cursor = create_connection(buyer_server, buyer_database, buyer_username, buyer_password)
#             test_fit_predict_refreshed_data(actual_series_id, cnxn, cursor)
#             forecast_status = 'success'
#         except pyodbc.Error as e:
#             forecast_status = 'failure'
#             exception = e
#     print("in end do_forecast")
#     print("forecast_status")
#     print(forecast_status)
#     print("exception")
#     print(exception)
#     return forecast_status, exception
