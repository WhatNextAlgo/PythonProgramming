"""
author: Harish Ganesh
"""
from datetime import date
from bs4 import BeautifulSoup
import pandas as pd
import urllib3
import azure_table
from helper import *
import multi_region_config_script 
import  MR_Credentials

def bls_reader(url):
    """
    This function retrieve url for a particular category
    :param url:string
    :return: links:list
    """
    req = urllib3.PoolManager()
    res = req.request('GET', url)
    soup = BeautifulSoup(res.data, 'html.parser')
    links = []
    for link in soup.find_all('a'):
        links.append("https://download.bls.gov" + link.get('href'))
    return links


def download_data(http, url):
    """
    This function download the time series data
    :param http: PoolManager Object
    :param url: url string from which to download data
    :return:file_name
    """
    # print("in")
    # print("url",url)
    r = http.request('GET', url, preload_content=False)
    file_name = url.split('/')[-1].split('.')[-1] + '.csv'
    #   with open(pjoin(BLS_datapath, file_name), 'wb+') as out:
    # with open('/dbfs/FileStore/tables/blS.csv', 'wb+') as out:
    with open('C:/Users/sandhya.harane/OneDrive - GEP/Mi-Data-New1/'+file_name, 'wb+') as out:
        # print(r.data)
        out.write(r.data)
    r.release_conn()
    return file_name


def format_date(year, period):
    # This function takes year and month from row of dataframe and convert it into date format
    return date(int(year), int(period[1:]), 1)


def split_file(
        file_name,
        cnxn,
        cursor,
        actual_series_id_dict,
        buyer_server,
        buyer_database,
        buyer_username,
        buyer_password):
    """
    This function will split the file in according to series id's
    :param file_name:name of the downloaded file as string
    :return:
    """

    df = pd.read_csv(pjoin(BLS_datapath, file_name), delimiter='\t')
    if len(df.index) == 0:  # checking if the csv file is empty
        return
    df.drop(df.columns[4], axis=1, inplace=True)
    df = df[df.period != 'M13']
    df['date'] = df.apply(lambda row: format_date(row['year'], row['period']), axis=1)
    df.drop(['year', 'period'], axis=1, inplace=True)
    df.rename(columns={df.columns[0]: df.columns[0].strip()}, inplace=True)
    df.rename(columns={df.columns[1]: df.columns[1].strip()}, inplace=True)
    df = df[['series_id', 'date', 'value']]
    df['series_id'] = df['series_id'].apply(lambda z: z.strip())
    set_ids = set(df['series_id'].values)

    for series_id in set_ids:
        if series_id in actual_series_id_dict.keys():

            #creating a df with a particular series id
            series_df = df[df['series_id'] == series_id]
            print(actual_series_id_dict[series_id][0])

            # repalcing the series id's with series id's from DB
            series_df["series_id"] = actual_series_id_dict[series_id][0]

            series_df = series_df.astype({"series_id": str, "date": str, "value": float})
            #series_df = series_df.tail(10)
            file_path = pjoin(BLS_datapath, series_id.strip() + '.csv')
            series_df.to_csv(file_path, index=False)

            sql_status, exception = load_prices_to_db(
                actual_series_id_dict[series_id][0], file_path, cnxn, cursor, buyer_server, buyer_database, buyer_username, buyer_password)

            forecast_status, exception = do_forecast(
                actual_series_id_dict[series_id][0], cnxn, cursor, buyer_server, buyer_database, buyer_username, buyer_password)

            try:
                azure_table.insert(
                    str(actual_series_id_dict[series_id][1]),
                    "BLS",
                    str(actual_series_id_dict[series_id][2]),
                    sql_status,
                    forecast_status,
                    str(exception))

            except BaseException:
                print("insertion into azure table failed for id = {}".format(actual_series_id_dict[series_id][1]))
    remove(pjoin(BLS_datapath, file_name))


def get_series_id(cnxn):
    print("in get_series_id")
    sql = """select seriesid,id,frequency from dbo.ds_CommodityMaster where website='BLS' and seriesid='Pcu11331-11331-/723';"""
    return cnxn.execute(sql)


def BLS_daily(bpc, reg_id):
    urls = ['https://download.bls.gov/pub/time.series/wp/', 'https://download.bls.gov/pub/time.series/pc/',
            'https://download.bls.gov/pub/time.series/ci/']
    mrObj=multi_region_config_script.get_multiregion_object()
    buyer_server, buyer_database, buyer_username, buyer_password = mrObj.get_buyer_db_connectionstring(bpc, reg_id)
    # buyer_server="tcp:hx67tx2ygu.database.windows.net,1433"
    # buyer_database="Dev_Datalake"
    # buyer_username="gep_sql_admin"
    # buyer_password="Password@123"
    cnxn, cursor = create_connection(buyer_server, buyer_database, buyer_username, buyer_password)
    #cnxn, cursor = create_connection()
    result = get_series_id(cnxn)
    print(result)
    df = pd.DataFrame(result.fetchall())
    series_id = dict()
    for row in df.itertuples():
        series_id[row[1][0].split('/')[0].upper()] = [row[1][0]]
        series_id[row[1][0].split('/')[0].upper()].append(row[1][1])
        series_id[row[1][0].split('/')[0].upper()].append(row[1][2])
    for url in urls:
        # getting links from the fred page
        links = bls_reader(url)
        # creating poolmanager object which take care of maintaining pool for multiple request
        http = urllib3.PoolManager()
        for link in links:
            # check if the link is data link or metadata link
            if link.find('data') != -1 and link.find('Current') == -1:
                file_name = download_data(http, link)
                split_file(
                    file_name,
                    cnxn,
                    cursor,
                    series_id,
                    buyer_server,
                    buyer_database,
                    buyer_username,
                    buyer_password,
                )
