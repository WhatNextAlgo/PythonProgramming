#Python default value arguments
def greets(name,msg="Good Morning!"):
    print(f"{name}, {msg}")


greets("Sumit")
greets("Rahul","How do you do?")

#Python Keyword arguments
# 1 positional, 1 keyword argument
greets("katie",msg="How do you do?")

def foreach(*args,**kargs):
    for x in args:
        print("Hello,",x)
    
    for key in kargs:
        print(key , kargs[key])


foreach("Monica", "Luke", "Steve", "John",one = "1",two="2",three="3")


#Python Anonymous/Lambda Function

twiceVal = lambda x : x*2
print(twiceVal(5))

my_list = [1, 5, 4, 6, 8, 11, 3, 12]
new_list = list(filter(lambda x : x % 2 == 0 ,my_list))
print(new_list)

new_list1 = list(map(lambda x : x * 2 ,my_list))
print(new_list1)






