def prefix_decorator(prefix):
    def decorator_function(orig_func):
        def wrapper(*args,**kargs):

            print(prefix, "Exceution before {}".format(orig_func.__name__))
            result  = orig_func(*args,**kargs)
            print(prefix, "Exceution After {}".format(orig_func.__name__))
            return result
        return wrapper
    return decorator_function

@prefix_decorator('TESTING: ')
def display_info(name,age):
    print("display_info function ran  with argument ({},{})".format(name,age))


display_info("Sumit",27)
        