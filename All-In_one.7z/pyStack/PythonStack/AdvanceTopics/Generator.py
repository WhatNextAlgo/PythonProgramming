def even_generator(max):
    n = 2
    while n <= max:
        yield n
        n += 2



for x in even_generator(4):
    print(x)

print("generator_fibonacci")


def generator_fibonacci(max):
    n1 = 0
    n2 = 1
    count = 1

    while count <= max:
        yield n1
        n1,n2 = n2 , n1+ n2
        count += 1

for x in generator_fibonacci(5):
    print(x)


#Generator Expression
print("Gnerator expression")
my_list = [1, 3, 6, 10]
# generator expressions are surrounded by parenthesis ()
generator = (x**2 for x in my_list)
for x in generator:
    print(x)

#If we want to find out the sum of squares of numbers in the Fibonacci series
print("If we want to find out the sum of squares of numbers in the Fibonacci series")
def fibonacci_numbers(nums):
    x, y  = 0,1
    for _ in range(nums):
        x,y = y ,x + y
        yield x

def squares(nums):
    for num in nums:
        yield num ** 2

print(sum(squares(fibonacci_numbers(10))))
