
import operator

def accumulate(iterable,func = operator.add,initial=None):
    it = iter(iterable)
    total = initial
    if initial is None:
        try:
            total = next(it)
        except StopIteration:
            return 
    yield total

    for element in it:
        total = func(total,element)
        yield total


data = [3, 4, 6, 2, 1, 9, 0, 7, 5, 8]

#print(list(accumulate(data,lambda x,y : (x + y) )))



pool = tuple('ABCD')
print(pool)
n = len(pool)
r = 2
indices = list(range(r))
print(indices)
print(tuple(pool[i] for i in indices))

while True:
    for i in reversed(range(r)):
        print(indices[i],i + n - r)
        if indices[i] != i + n - r:
            break
    else:
        break

    print("i",i)
    indices[i] += 1
    #print(indices)
    for j in range(i + 1,r):
        indices[j] = indices[j-1] + 1

    print("last =", indices)
    
    #yield tuple(pool[i] for i in indices)

    l = list(1,2,3,4)



