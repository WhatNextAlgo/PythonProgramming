import datetime as dt
from time import time

current_date = dt.date.today()
print(current_date.year,current_date.month,current_date.day,sep="-")

time1 = dt.time(10,45,15)
print(time1)