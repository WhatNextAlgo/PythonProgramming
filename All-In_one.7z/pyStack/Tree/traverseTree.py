#Write a Program to traverse a Tree
#1. Inoreder traverse
#2. preoreder traverse
#2. postoreder traverse

class Node:
    def __init__(self,item):
        self.left = None
        self.right = None
        self.val = item


def Inorder(root):
    if root:
        Inorder(root.left)
        print(str(root.val),end=" --> ")
        Inorder(root.right)


def preorder(root):
    if root:
        print(str(root.val),end="-->")
        preorder(root.left)
        preorder(root.right)

def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(str(root.val),end="-->")


root = Node(1)
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)

print("Inorder traversal ")
Inorder(root)

print("\nPreorder traversal ")
preorder(root)

print("\nPostorder traversal ")
postorder(root)
print()
print(10,"1")
print(10*3,"2")
print(30*3,"3")
print(90*3,"4")
print(270*3,"5")

