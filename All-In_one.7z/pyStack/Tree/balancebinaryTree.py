class Node:
    def __init__(self,item):
        self.item = item
        self.left = self.right = None


def height(root):
    if root is None:
        return 0

    return max(height(root.left),height(root.right)) + 1

def is_balanced(root):

    if root is None:
        return True
    
    l = height(root.left)
    r = height(root.right)
    
    
    # print("left",l)
    # print("right",r)
    # print()
    
    if abs(l -r) <= 1 and is_balanced(root.left) is True and is_balanced(root.right):
        return True


    return False





root = Node(1)
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)
root.left.left.left = Node(8)
root.left.left.left.left = Node(9)
if is_balanced(root):
    print("Tree is balanced")
else:
    print("Tree is not balanced")


