# Python Program to Find All Nodes Reachable from a Node using BFS in a Graph
# This is a Python program to find all nodes reachable from a node using BFS in a graph.

# Problem Description
# The program creates a graph object and allows the user to find all nodes reachable from a node.

# Problem Solution
# 1. Create classes for Graph, Vertex and Queue.
# 2. Create a function find_all_reachable_nodes that takes a Vertex object as argument.
# 3. The function begins by creating an empty set called visited and a Queue object, q.
# 4. It enqueues the passed Vertex object and also adds it to the set visited.
# 5. A while loop is created which runs as long as the queue is no empty.
# 6. In each iteration of the loop, the queue is dequeued and all of its neighbours are enqueued which have not already been visited.
# 7. In addition to enqueuing, they are also added to the visited set.
# 8. After the loop is finished, the set visited is returned. The set contains all vertices that can be reached from the source vertex.
# 9. This algorithm also works for undirected graphs. In an undirected graph, whenever edge (u, v) is added to the graph, the reverse edge (v, u) is also added.

class Graph:
    def __init__(self):
        self.vertices = {}

    def get_vertex(self,key):
        return self.vertices[key]

    def add_vertex(self,key):
        vertex = Vertex(key)
        self.vertices[key] = vertex

    def add_edge(self,src_key,dest_key,weight=1):
        self.vertices[src_key].add_neighbour(self.vertices[dest_key],weight)

    def does_edge_exist(self,src_key,dest_key):
        return self.vertices[src_key].does_it_point_to(self.vertices[dest_key])

    def __contains__(self,key):
        return key in self.vertices

    def __iter__(self):
        return iter(self.vertices.values())


class Vertex:
    def __init__(self,key):
        self.key = key 
        self.point_to = {}

    def get_key(self):
        return self.key
    
    def get_neighbours(self):
        return self.point_to.keys()

    def add_neighbour(self,dest,weight=1):
        self.point_to[dest] = weight

    def get_weight(self,dest):
        return self.point_to[dest]

    def does_it_point_to(self,dest):
        return dest in self.point_to


class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def enqueue(self,key):
        self.items.append(key)

    def dequeue(self):
        return self.items.pop(0)


def find_all_reachable_nodes(vertex):
    visited = set()

    q =Queue()
    q.enqueue(vertex)
    visited.add(vertex)

    while not q.is_empty():
        current = q.dequeue()
        print(current.get_key(),end =" ")
        for dest in current.get_neighbours():
            if dest not in visited:
                visited.add(dest)
                q.enqueue(dest)

    return visited


g = Graph()
print('Menu')
print('add vertex <key>')
print('add edge <src> <dest>')
print('reachable <vertex key>')
print('display')
print('quit')
 
while True:
    do = input('What would you like to do? ').split()
 
    operation = do[0]
    if operation == 'add':
        suboperation = do[1]
        if suboperation == 'vertex':
            key = int(do[2])
            if key not in g:
                g.add_vertex(key)
            else:
                print('Vertex already exists.')
        elif suboperation == 'edge':
            src = int(do[2])
            dest = int(do[3])
            if src not in g:
                print('Vertex {} does not exist.'.format(src))
            elif dest not in g:
                print('Vertex {} does not exist.'.format(dest))
            else:
                if not g.does_edge_exist(src, dest):
                    g.add_edge(src, dest)
                else:
                    print('Edge already exists.')
 
    elif operation == 'reachable':
        key = int(do[1])
        vertex = g.get_vertex(key)
        reachable = find_all_reachable_nodes(vertex)
        print('All nodes reachable from {}:'.format(key),
              [v.get_key() for v in reachable])
 
    elif operation == 'display':
        print('Vertices: ', end='')
        for v in g:
            print(v.get_key(), end=' ')
        print()
 
        print('Edges: ')
        for v in g:
            for dest in v.get_neighbours():
                w = v.get_weight(dest)
                print('(src={}, dest={}, weight={}) '.format(v.get_key(),
                                                             dest.get_key(), w))
        print()
 
    elif operation == 'quit':
        break