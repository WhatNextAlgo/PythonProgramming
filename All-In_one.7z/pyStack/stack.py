class ArrayStack:
    def __init__(self):
        self.data = []

    def __len__(self):
        return len(self.data)

    def is_empty(self):
        return len(self.data) == 0
    
    def push(self,e):
        self.data.append(e)

    def top(self):

        if self.is_empty():
            raise Empty('Stack is Empty')
        return self.data[-1]

    def pop(self):
        if self.is_empty():
            raise Empty('Stack is Empty')
        return self.data.pop()

    def print_stack(self):
        print(self.data)


#Remove Outermost Parentheses
input_value = "(()())(())(()(()))"

def validate_parenthess(input_value):
    string = ""
    s = ArrayStack()
    lst = list(input_value)
    
    for x in lst:
        if x == "(":
            if s.is_empty():
                s.push(x)
            else:
                top_val = s.top()
                if x != top_val:
                    s.push(x)
        else:
            top_val = s.top()
            if x != top_val:
                s.push(x)
    
    
    new_stack = ArrayStack()
    while not s.is_empty():
        new_stack.push(s.pop())
    
    while not new_stack.is_empty():
        string += new_stack.pop()

    return string
        
        



#print(validate_parenthess(input_value))

