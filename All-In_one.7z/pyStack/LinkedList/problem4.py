# This is a Python program to display the nodes of a linked list in reverse using recursion.

# Problem Description
# The program creates a linked list using data items input from the user and displays it in reverse.

# Problem Solution
# 1. Create a class Node.
# 2. Create a class LinkedList.
# 3. Define methods append and display inside the class LinkedList to append data and display the linked list respectively.
# 4. Define methods display_reversed and display_reversed_helper.
# 5. display_reversed calls display_reversed_helper to display the list recursively in reverse.
# 6. Create an instance of LinkedList, append data to it and display the list in reverse order.

class Node:
    def __init__(self,data):
        self.data = data 
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None

    def append(self,data):
        if self.last_node is None:
            self.head = Node(data)
            self.last_node =self.head
        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next

    def display_reversed(self):
        self.display_reversed_helper(self.head)


    def display_reversed_helper(self,current):
        if current is None:
            return 
        self.display_reversed_helper(current.next)
        print(current.data,end=" ")

         
a_llist = LinkedList()
n = int(input('How many elements would you like to add? '))
for i in range(n):
    data = int(input('Enter data item: '))
    a_llist.append(data)
 
print('The reversed linked list: ', end = '')
a_llist.display_reversed()