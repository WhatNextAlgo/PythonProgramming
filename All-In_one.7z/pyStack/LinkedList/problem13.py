# This is a Python program to implement a queue using a linked list.

# Problem Description
# The program creates a queue and allows the user to perform enqueue and dequeue operations on it.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class Queue with instance variables head and last.
# 3. The variable head points to the first element in the linked list while last points to the last element.
# 4. Define methods enqueue and dequeue inside the class Queue.
# 5. The method enqueue adds a node at the end of the linked list.
# 6. The method dequeue returns the data of the node at the front of the linked list and removes the node. It returns None if there are no nodes.
# 7. Create an instance of Queue and present a menu to the user to perform operations on the queue.

class Node:
    def __init__(self,data):
        self.data = data 
        self.next = None

class Queue:
    def __init__(self):
        self.head = None
        self.last_node = None


    def enqueue(self,value):
        if self.head is None:
            self.head = Node(value)
            self.last_node = self.head

        else:
            self.last_node.next = Node(value)
            self.last_node = self.last_node.next


    def dequeue(self):
        if self.head is None:
            return None
        else:
            to_return = self.head.data
            self.head = self.head.next
            return to_return

a_queue = Queue()
while True:
    print('enqueue <value>')
    print('dequeue')
    print('quit')
    do = input('What would you like to do? ').split()
 
    operation = do[0].strip().lower()
    if operation == 'enqueue':
        a_queue.enqueue(int(do[1]))
    elif operation == 'dequeue':
        dequeued = a_queue.dequeue()
        if dequeued is None:
            print('Queue is empty.')
        else:
            print('Dequeued element: ', int(dequeued))
    elif operation == 'quit':
        break