# This is a Python program to print the middle node(s) of a linked list.

# Problem Description
# The program creates a linked list using data items input from the user and prints the middle node(s) of the linked list.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define methods append and display inside the class LinkedList to append data and display the linked list respectively.
# 5. Define a function print_middle that prints the middle element(s) of the list.
# 6. The function print_middle iterates through the list to find its length and then iterates again to half its length. If the length of the list is even, it prints two middle elements.
# 7. Create an instance of LinkedList, append data to it and print its middle element(s).


class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None


    def append(self,data):
        if self.last_node is None:
            self.head  = Node(data)
            self.last_node = self.head

        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next


def print_middle(alist):
    if alist.head is None:
        return 0

    current = alist.head
    length = 0

    while current:
        current = current.next
        length = length + 1

    current = alist.head

    for i in range((length-1)//2):
        current = current.next

    if current:
        if length % 2 == 0:
            print('The two middle elements are {} and {}.'
                .format(current.data, current.next.data))

        else:
             print('The middle element is {}.'.format(current.data))

    else:
        print('The list is empty.')


a_llist = LinkedList()
 
data_list = input('Please enter the elements in the linked list: ').split()
for data in data_list:
    a_llist.append(int(data))
 
print_middle(a_llist)

    