# This is a Python program to interchange two nodes in a linked list.

# Problem Description
# The program creates a single linked list and allows the user to interchange two nodes in the list.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define methods get_node, get_prev_node, append and display.
# 5. get_node takes an index as argument and traverses the list from the first node that many times to return the node at that index.
# 6. get_prev_node takes a reference node as argument and returns the previous node.
# 7. The method display traverses the list from the first node and prints the data of each node.
# 8. The method append appends a node with the data item passed to the end of the list.
# 9. Define the function interchange which takes a linked list and two indices n and m as arguments.
# 10. The function interchange interchanges the nodes at indices n and m.
# 11. Create an instance of LinkedList, append data to it and perform the exchange operation.

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
 
 
class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None
 
    def append(self, data):
        if self.last_node is None:
            self.head = Node(data)
            self.last_node = self.head
        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next
 
    def display(self):
        current = self.head
        while current:
            print(current.data, end = ' ')
            current = current.next
 
    def get_node(self, index):
        current = self.head
        for i in range(index):
            if current is None:
                return None
            current = current.next
        return current
 
    def get_prev_node(self, ref_node):
        current = self.head
        while (current and current.next != ref_node):
            current = current.next
        return current


def interchange(alist,n,m):
    node1 = alist.get_node(n)
    node2 = alist.get_node(m)
    prev_node1 = alist.get_prev_node(node1)
    prev_node2 = alist.get_prev_node(node2)

    if prev_node1 is not None:
        prev_node1.next = node2
    else:
        alist.head = node2

    if prev_node2 is not None:
        prev_node2.next = node1
    else:
        alist.head = node1

    temp = node2.next
    node2.next = node1.next
    node1.next = temp

a_llist = LinkedList()
 
data_list = input('Please enter the elements in the linked list: ').split()
for data in data_list:
    a_llist.append(int(data))
 
ans = input('Please enter the two indices of the two elements that'
            ' you want to exchange: ').split()
n = int(ans[0])
m = int(ans[1])
 
interchange(a_llist, n, m)
 
print('The new list: ')
a_llist.display()