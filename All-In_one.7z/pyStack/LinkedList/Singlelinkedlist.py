class Node:
    def __init__(self,value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self,):
        self.head = None
        self.tail = None

    def insertAtEnd(self,value):
        new_node = Node(value)
        if self.head == None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def insertAtBeginning(self,value):
        new_node = Node(value)

        if self.head == None:
            self.head= new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node

    def insertAfter(self,node,value):
        if node is None:
            print("The given previous node must inLinkedList.")
            return

        new_node = Node(value)
        
        new_node.next = node.next
        node.next = new_node

    def deleteNode(self,position):
        count = 1
        if self.head == None:
            print("Linked List is Empty")
            return
        
        temp_node = self.head
        if position == 0:
            self.head = temp_node.next
            temp_node = None
            return

        while temp_node.next and count != position:
            temp_node = temp_node.next
            count = count + 1

        if temp_node is None:
            return
        
        if temp_node.next is None:
            return 
        
        print(temp_node.value,"print node value")
        next = temp_node.next.next
        temp_node.next = None
        temp_node.next = next


    def printList(self):
        temp_node = self.head
        while (temp_node):
            print(str(temp_node.value) + " ", end="")
            temp_node = temp_node.next

            

llist = LinkedList()
llist.insertAtEnd(1)
llist.insertAtBeginning(2)
llist.insertAtBeginning(3)
llist.insertAtEnd(4)
llist.insertAfter(llist.head.next, 5)

print('Linked list:')
llist.printList()

print("\nAfter deleting an element:")
llist.deleteNode(3)
llist.printList()