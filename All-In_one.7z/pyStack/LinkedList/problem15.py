# This is a Python program to illustrate the operations of a singly linked list.

# Problem Description
# The program creates a singly linked list and presents the user with a menu to perform various operations on the list.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variable head.
# 3. The variable head points to the first element in the singly linked list.
# 4. Define methods get_node, get_prev_node, insert_after, insert_before, insert_at_beg, insert_at_end, remove and display.
# 5. get_node takes an index as argument and traverses the list from the first node that many times to return the node at that index.
# 6. get_prev_node takes a reference node as argument and returns the previous node. It returns None when the reference node is the first node.
# 7. The methods insert_after and insert_before insert a node after or before some reference node in the list.
# 8. The methods insert_at_beg and insert_at_end insert a node at the first or last position of the list.
# 9. The method remove takes a node as argument and removes it from the list.
# 10. The method display traverses the list from the first node and prints the data of each node.
# 11. Create an instance of LinkedList and present the user with a menu to perform operations on the list.

class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head   =None

    def get_node(self,index):
        current = self.head 
        for i in range(index):
            if current is None:
                return None
            current = current.next
        return current

    def insert_after(self,ref_node,new_node):
        new_node.next = ref_node.next

        if ref_node.next is None:
            self.last = new_node

        ref_node.next = new_node

    def insert_before(self,ref_node,new_node):
        prev_node = self.get_prev_node(ref_node)
        self.insert_after(prev_node,new_node)
    
    def get_prev_node(self,ref_node):
        current = self.head
        while current and current.next != ref_node:
            current = current.next

        return current


    def insert_at_end(self,new_node):
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next is not None:
                current = current.next
            current.next = new_node
        

    def insert_at_beg(self,new_node):
        if self.head is None:
            self.head = new_node
        else:
            new_node.next = self.head
            self.head = new_node


    def remove(self, node):
        prev_node = self.get_prev_node(node)
        if prev_node is None:
            self.head = self.head.next
        else:
            prev_node.next = node.next

    
    def display(self):
        current = self.head
        while current:
            print(current.data,end=" ")
            current = current.next
    


a_llist = LinkedList()
 
print('Menu')
print('insert <data> after <index>')
print('insert <data> before <index>')
print('insert <data> at beg')
print('insert <data> at end')
print('remove <index>') 
print('quit')
 
while True:
    print('The list: ', end = '')
    a_llist.display()
    print()
    do = input('What would you like to do? ').split()
 
    operation = do[0].strip().lower()
 
    if operation == 'insert':
        data = int(do[1])
        position = do[3].strip().lower()
        new_node = Node(data)
        suboperation = do[2].strip().lower() 
        if suboperation == 'at':
            if position == 'beg':
                a_llist.insert_at_beg(new_node)
            elif position == 'end':
                a_llist.insert_at_end(new_node)
        else:
            index = int(position)
            ref_node = a_llist.get_node(index)
            if ref_node is None:
                print('No such index.')
                continue
            if suboperation == 'after':
                a_llist.insert_after(ref_node, new_node)
            elif suboperation == 'before':
                a_llist.insert_before(ref_node, new_node)
 
    elif operation == 'remove':
        index = int(do[1])
        node = a_llist.get_node(index)
        if node is None:
            print('No such index.')
            continue
        a_llist.remove(node)
 
    elif operation == 'quit':
        break

            