
# This is a Python program to find the first element of the first linked list that is common to both the lists.

# Problem Description
# The program creates two linked lists using data items input from the user and determines the first element in the first linked list that is in both the lists.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define methods append and display inside the class LinkedList to append data and display the linked list respectively.
# 5. Define a function first_common which takes two linked lists as arguments.
# 6. The function first_common returns the first element in the first linked list that is common to both the linked lists using two nested loops.
# 7. Create two instances of LinkedList and append data to it.
# 8. Find the common element and display the result.




class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None


    def append(self,data):
        if self.last_node is None:
            self.head  = Node(data)
            self.last_node = self.head

        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next


def first_common(list1,list2):
    current1  = list1.head
    while current1:
        data = current1.data
        current2 = list2.head
        while current2:
            if data == current2.data:
                return data

            current2 = current2.next
        current1 = current1.next
    return None


llist1 = LinkedList()
llist2 = LinkedList()
 
data_list = input('Please enter the elements in the first linked list: ').split()
for data in data_list:
    llist1.append(int(data))
 
data_list = input('Please enter the elements in the second linked list: ').split()
for data in data_list:
    llist2.append(int(data))
 
common = first_common(llist1, llist2)
 
if common:
    print('The element that appears first in the first linked list that'
          ' is common to both is {}.'.format(common))
else:
    print('The two lists have no common elements.')