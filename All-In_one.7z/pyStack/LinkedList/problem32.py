# This is a Python program to print the Nth node from the end of a linked list.

# Problem Description
# The program creates a linked list and prints the Nth node from the end of the list.

# Problem Solution
# 1. Create a class Node with instance variables data and next.
# 2. Create a class LinkedList with instance variables head and last_node.
# 3. The variable head points to the first element in the linked list while last_node points to the last.
# 4. Define method append.
# 5. The method append appends a node with the data item passed to the end of the list.
# 6. Define the function length_llist which takes a linked list as argument and returns its length.
# 7. Define the function return_n_from_last which takes a linked list as argument and a number n.
# 8. The function return_n_from_last returns the data item of the node which is n nodes from the end of the list.
# 9. Create an instance of LinkedList, append data to it and print the nth-last element of the list.


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
 
 
class LinkedList:
    def __init__(self):
        self.head = None
        self.last_node = None
 
    def append(self, data):
        if self.last_node is None:
            self.head = Node(data)
            self.last_node = self.head
        else:
            self.last_node.next = Node(data)
            self.last_node = self.last_node.next


def length_llist(alist):
    length = 0
    current = alist.head
    while current:
        current = current.next
        length = length + 1

    return length

def return_n_from_last(alist,n):
    if n== 0:
        return None
    l = length_llist(alist)
    current = alist.head

    for i in range(l-n):
        current = current.next
    return current.data

a_llist = LinkedList()
 
data_list = input('Please enter the elements in the linked list: ').split()
for data in data_list:
    a_llist.append(int(data))
 
n = int(input('The nth element from the end will be printed. Please enter n: '))
value = return_n_from_last(a_llist, n)
 
print('The nth element from the end: {}'.format(value))