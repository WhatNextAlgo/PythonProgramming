from array import *

#1.Crete a array and traverse.
# my_array = array('i',[1,2,3,4,5])


# for i in my_array:
#     print(i)

# #2.Access individual elements through indexes
# print("Step 2")
# print(my_array[0])

# #3.Append any value to the array using append()
# print("Step 3")
# my_array.append(10)
# print(my_array)

# #4. Insert value in a array using insert()
# print("Step 4")
# my_array.insert(0,11)
# print(my_array)

# #5 Extend python array using extend()
# print("Step 5")
# my_array1 = array('i',[12,13,14])

# my_array.extend(my_array1)
# print(my_array)

# #6 add items from list into array using fromlist()
# print("Step 5")
# lst = [20,21,22]
# my_array.fromlist(lst)
# print(my_array)

# #7. Remove any array using Remove()
# print("Step 7")
# my_array.remove(22)
# print(my_array)

# #8.remove last element using pop()
# print("Step 8")
# my_array.pop()
# print(my_array)

# #9. Fetch any element through index usnf index()
# print("Step 9")

# print(my_array.index(20))

# #10. Reverse a python array using reverse()
# print("Step 10")
# my_array.reverse()
# print(my_array)

# #11. get array buffer informtion using buffer_info()
# print("Step 11")
# print(my_array.buffer_info())

# #12. check for number of occcurance of an element using count()
# print("Step 12")
# my_array.append(11)
# print(my_array.count(11))

# #13. Convert array to string using tostring()
# print("Step 13")
# temp_str = my_array.tostring()
# print(temp_str)
# ints = array('i')
# ints.fromstring(temp_str)
# print(ints)
# #14. convert array to python list using tolist()
# print("Step 14")

# print(my_array.tolist())

# #15. Slice elements from an array

# print("Step 15")
# print(my_array[0:4])


#Two Dimension array
import numpy as np

np_array = np.array([[1,10,11],[5,4,10],[24,50,37]])
print(np_array)

newTwoDArray = np.insert(np_array,1,[[1,2,3]],axis=0)
#print(newTwoDArray)



def accessElement(array,rowIndex,colIndex):
    if rowIndex >= len(array) and colIndex >= len(array[0]):
        print("Incorrect index")
    else:
        print(array[rowIndex][colIndex])

#accessElement(newTwoDArray,1,2)

for x in range(len(np_array)):
    for y in range(len(np_array[0])):
        print(np_array[x][y])


def searchElement(array,elm):
    for x in range(len(array)):
        for y in range(len(array[0])):
            val = array[x][y] 
            if val == elm:
                return f"{val} is located at index {x},{y}"

    return 'element not found'

print("result : ",searchElement(np_array,10))