# from pyspark.sql import SparkSession
# from pyspark.dbutils import DBUtils
# spark = SparkSession\
# .builder\
# .getOrCreate()

# spark.conf.set(
#   "fs.azure.account.key.scmdevdpdatalake.dfs.core.windows.net", "xy+w+9tLBMRso0+DQQjnHSDX4KE8CPZmM6oIUSsAenef3IK5rsa7nm1Gk4UDS6sIVE/dEQe1hLMk6YTIEsEnGQ==")
# print("Testing simple count")
# # The Spark code will execute on the Databricks cluster.
# print(spark.range(100).count())

# dbutils = DBUtils(spark)
# print(dbutils.fs.ls("dbfs:/"))



#!/bin/python3

import math
import os
import random
import re
import sys
import numpy as np
from collections import Counter


# Complete the compareTriplets function below.
def compareTriplets(a):
      value  = 0
      if a>1:
            for i in a:
                  value = value + i

      return value            
         
                        
                        
def computeArr(s):
      

      if "PM" in s:
            if int(s[:2]) < 12 :
                  val = int(s[:2]) + 12
                  print(val)
                  result = str(val)+s[2:8]
                  return result
            elif (s[:2]) == "12" and s[3:5] == "00" and s[6:8] == "00":
                  return s[:8]

            elif (s[:2]) == "12" and s[3:5] != "00" and s[6:8] != "00":
                  return s[:8]                                   
      elif "AM" in s:
            if (s[:2]) == "12" and s[3:5] == "00" and s[6:8] == "00":
                  val = "00"+s[2:8]
                  return val
            elif (s[:2]) == "12"and s[3:5] != "00" and s[6:8] != "00":

                  return "00"+s[2:8] 
            else:
                  return s[:8] 


                 
def grade(arr):
      print(arr)
      grades =[]

      for i in arr:
            multipleOfFive = ((int(i)//5) + 1) * 5
            print(multipleOfFive)
            if (multipleOfFive - i) <3 and i>37:
                  grades.append(multipleOfFive)
            else:
                  grades.append(i)


      print(grades)            

def countApplesAndOranges(s, t, a, b, apples, oranges):
      ac = 0
      oc =0
      for i in apples:
            if (i + a) >=s and (i + a) <= t:
                  ac = ac +1

      for j in oranges:
            if (j + b) >=s  and (j + b) <= t:
                  oc = oc +1
      print(ac)
      print(oc)
    
def kangaroo(x1, v1, x2, v2):


      if (v1 > v2) and (x2 - x1) % (v2 - v1) == 0:
            return "YES"
  
      else:
            return "NO"  






def fibonacci(n):


    # return a list of fibonacci numbers
      fib = [0,1]
      if n == 0:
            return []
      elif n == 1:
            return [0]
      elif n == 2:
            return [0,1]          
      else:
            for i in range(2,n):
                  fib.append(fib[i-1]+fib[i-2])

            return fib          
def gcd(a,b): 
    if a == 0: 
        return b 
    return gcd(b % a, a) 
  
# Function to return LCM of two numbers 
def lcm(a,b): 
    return (a*b) / gcd(a,b) 
  

def getTotalX1(a, b):

      first = []


      for i in a:
            for j in range(1,10):
                  first.append(a*j)


      

      covertSetToList = list(set(first))

      for i in b:
            for j in covertSetToList:
                  if i%j != 0:
                        covertSetToList.remove(j)


      return len(covertSetToList)       

def getTotalX(a,b):

      x=a[len(a)-1]
      y=b[0]
      print("a",x)
      print("b",y)
      count=0

      for p in range(x,y+1):
            chk=0
            for i in b:
                  print("1---%",i,p)
                  if i%p!=0:
                        print("1---%!",i,p)
                        chk=1
                        break
            if chk == 1:
                  continue
            else:
                  chk1=0
                  for i in a:
                        print("2---%",p,i)
                        if p%i!=0:
                              print("2---%!",p,i)
                              chk1=1
                              break
                  if chk1==0:
                        count+=1
      print(count) 
        
#remainder for learn ploy function
def birthday(s, d, m):
      count =0 
      for i in  range(len(s)):
            if (len(s[i:i+m]) == m) and (sum(s[i:i+m]) == d):
                  count = count +1
      print(count)            


def divisibleSumPairs(n, k, ar):
      count = 0
      for i in range(len(ar)-1):

            for j in range(i+1,len(ar)):
                  if (ar[i]+ar[j])%k == 0:
                              count = count + 1


      print(count)                  

def migratoryBirds(arr):

      migratoryBirdsType = {}
      for i in range(1,6):
            migratoryBirdsType[i] = 0

      for i in arr:
             migratoryBirdsType[i] += 1 

      Keymax = max(migratoryBirdsType, key=migratoryBirdsType.get) 
      print(Keymax) 
      print(migratoryBirdsType[Keymax])       

def dayOfProgrammer(year):
      if year == 1918:
            print('26.09.1918')

      elif ((year < 1918) and (year%4 == 0)) or ((year > 1918) and (year%400) ==0 or (year%4 == 0 and  year%100 !=0)):
            month = 256 - 244
            print(f"{month}:9:{year}")
      else:
            month = 256 - 243
            print(f"{month}:9:{year}")
def bonAppetit(bill, k, b):
      bill.remove(bill[k])
      bActual = sum(bill)/2
      bcharged = b - bActual
      if bcharged == 0:
            print("Bon Appetit")
      else:
            print(int(bcharged))      


def sockMerchant(n, ar):
      count = 0
      for i in Counter(ar).values():
            count += i//2

      print(count)

if __name__ == "__main__":



      
      n = int(input())

      ar = list(map(int, input().rstrip().split()))

      result = sockMerchant(n, ar)



      
      # isEmailLenghtValid = lambda x : len(x) >10 and len(x) < 80
      

      # if isEmailLenghtValid(email):
      #       ptrn = re.compile("^[a-zA-Z][\w-]*@[a-zA-Z0-9]+\.[a-zA-Z]{1,3}$")
      #       if re.match(ptrn,email) == None:
      #           return False
      #       else:
      #             return True


      
      # arr = np.array([list(map(int,input().rstrip().split()))])

      # print(np)
     
      # arr1=np.array([list(map(int,input().split())) for _ in range(a)])

      # arr2=np.array([list(map(int,input().split())) for _ in range(a)])

      # print(np.inner(arr1,arr2))
      # print(np.outer(arr1,arr2))

      # n = int(input())
      # a=np.array(list(map(int,input().rstrip().split())),int)
      # b=np.array(list(map(int,input().rstrip().split())),int)
        

      # print(a)   
      # print(b)  
      # print()
      # print(np.mean(a, axis = 1))
      # print(np.var(a, axis = 0))
      # print(round(np.std(a,axis = None),11))
      
         
            


      