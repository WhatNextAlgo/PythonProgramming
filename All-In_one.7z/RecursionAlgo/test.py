import turtle

bob = turtle.Turtle()

# bob.forward(100)
# bob.left(45)
# bob.forward(100)
# bob.right(90)
# bob.forward(100)
bob.color("blue","cyan")
bob.begin_fill()
bob.forward(100)
bob.right(90)
bob.forward(100)
bob.right(90)
bob.forward(100)
bob.right(90)
bob.forward(100)

bob.penup()
bob.forward(50)
bob.pendown()
bob.forward(100)
bob.right(90)
bob.forward(100)
bob.right(90)
bob.forward(100)
bob.right(90)
bob.forward(100)
bob.end_fill()







turtle.done()