def moveTower(Height,fromPole,toPole,WithPole):
    if Height > 1:
        moveTower(Height - 1,fromPole,WithPole,toPole)
        moveDisk(fromPole,toPole)
        moveTower(Height - 1,WithPole,toPole,fromPole)

def moveDisk(fp,tp):
    print("moving disk from",fp,"to",tp)
         

moveTower(3,"A","B","C")         