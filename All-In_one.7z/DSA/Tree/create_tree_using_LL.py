
from  QueueLinkedList import Queue

class TreeNode:
    def __init__(self,data):
        self.data = data
        self.leftChild = None
        self.rightChild = None

def preorder_traversal(root_node):
    if not root_node:
        return
    print(root_node.data, end = " ")
    preorder_traversal(root_node.leftChild)
    preorder_traversal(root_node.rightChild)


def inorder_traversal(root_node):
    if not root_node:
        return
    inorder_traversal(root_node.leftChild)
    print(root_node.data, end = " ")
    inorder_traversal(root_node.rightChild)


def postorder_traversal(root_node):
    if not root_node:
        return

    postorder_traversal(root_node.leftChild)
    postorder_traversal(root_node.rightChild)
    print(root_node.data, end = " ")


def levelorder_traversal(root_node):
    if not root_node:
        return 
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            print(root.data,end=" ")
            if (root.leftChild is not None):
                queue.enqueue(root.leftChild )

            if (root.rightChild is not None):
                queue.enqueue(root.rightChild )


def search_node(root_node,node):
    if not root_node:
        return "The BT does not exist"
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            if root.data == node:
                return "Success"
            if (root.leftChild is not None):
                queue.enqueue(root.leftChild )

            if (root.rightChild is not None):
                queue.enqueue(root.rightChild ) 
    
        return "Not Found"

def insert_node(root_node,new_node):
    if not root_node:
        root_node = new_node
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            if (root.leftChild is not None):
                queue.enqueue(root.leftChild)
            else:
                root.leftChild = new_node
                return

            if (root.rightChild is not None):
                queue.enqueue(root.rightChild )
            else:
                root.rightChild = new_node
                return


def get_deepest_node(root_node):
    if not root_node:
        return "The BT does not exist"
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            if (root.leftChild is not None):
                queue.enqueue(root.leftChild )

            if (root.rightChild is not None):
                queue.enqueue(root.rightChild ) 

        deepest_node = root
        return deepest_node

def delete_deepest_node(root_node,dNode):
    if not root_node:
        return
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            if root is dNode:
                root = None

            if (root.rightChild is not None):
                if root.rightChild is dNode:
                    root.rightChild = None
                    return
                else:
                    queue.enqueue(root.rightChild) 
            
            if (root.leftChild is not None):
                if root.leftChild is dNode:
                    root.leftChild = None
                    return
                else:
                    queue.enqueue(root.leftChild) 


def delete_node(root_node,value):
    if not root_node:
        return "BT does not exist"
    else:
        queue = Queue()
        queue.enqueue(root_node)
        while not queue.is_empty():
            root = queue.dequeue()
            if root.data == value:
                dNode = get_deepest_node(root_node)
                root.data = dNode.data
                delete_deepest_node(root_node,dNode)
                return "The node has been successfully deleted"

            if (root.leftChild is not None):
                queue.enqueue(root.leftChild )

            if (root.rightChild is not None):
                queue.enqueue(root.rightChild ) 

        return "Failed to delete"



def delete_bt(root_node):
    if not root_node:
        return
    else:
        root_node.data = None
        root_node.leftChild = None
        root_node.rightChild= None



                
            



if __name__ == "__main__":
    bt = TreeNode("Drinks")
    leftChild = TreeNode("Hot")
    rightChild = TreeNode("Cold")
    bt.leftChild = leftChild
    bt.rightChild = rightChild
    bt.leftChild.leftChild = TreeNode("Tea")
    bt.leftChild.rightChild = TreeNode("Coffee")

    bt.rightChild.leftChild = TreeNode("Cola")
    bt.rightChild.rightChild = TreeNode("Fanta")

    # preorder_traversal(bt)
    # print("--pre-order traversal")
    # inorder_traversal(bt)
    # print("--in-order travesal")
    # postorder_traversal(bt)
    # print("--post-order travesal")
    # levelorder_traversal(bt)
    # print("--level-order traversal")
    # print(search_node(bt,"Tea"))

    # insert_node(bt,TreeNode("Hot Tea"))
    # insert_node(bt,TreeNode("Cold Tea"))
    # levelorder_traversal(bt)
    # print("--level-order traversal")
    # print("deepest_node",get_deepest_node(bt).data)
    # delete_deepest_node(bt,get_deepest_node(bt))
    # levelorder_traversal(bt)
    # print("--level-order traversal")
    #delete_node(bt,"Tea")
    #delete_bt(bt)
    levelorder_traversal(bt)
    print("--level-order traversal")
    
    


    