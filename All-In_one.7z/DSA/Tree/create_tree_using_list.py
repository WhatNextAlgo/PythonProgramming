
class BinaryTree:
    def __init__(self,size):
        self.customList = [None] * size
        self.lastUsedIndex = 0
        self.mazSize = size

    def insertNode(self,value):
        if self.lastUsedIndex +1 == self.mazSize:
            return "The Binary Tree is full"

        self.customList[self.lastUsedIndex + 1] = value
        self.lastUsedIndex += 1
        return "The value has been successfully inserted"

    def searchNode(self,nodeValue):
        for i in range(len(self.customList)):
            if self.customList[i] == nodeValue:
                return "Success"
        return "Not found"

    def preorder_traversal(self,index):
        if index > self.lastUsedIndex:
            return
        print(self.customList[index])
        self.preorder_traversal(index*2)
        self.preorder_traversal(index*2 + 1)

    def inorder_traversal(self,index):
        if index > self.lastUsedIndex:
            return
        self.inorder_traversal(index*2)
        print(self.customList[index])
        self.inorder_traversal(index*2 + 1)


    def postorder_traversal(self,index):
        if index > self.lastUsedIndex:
            return
        self.postorder_traversal(index*2)
        self.postorder_traversal(index*2 + 1)
        print(self.customList[index])

    def levelorder_traversal(self,index):
        for i in range(index,self.lastUsedIndex+1):
            print(self.customList[i])



    def deleteNode(self,value):
        if self.lastUsedIndex == 0:
            return "There is no element in binary tree"

        for i in range(1,self.lastUsedIndex + 1):
            if self.customList[i] == value:
                self.customList[i] = self.customList[self.lastUsedIndex]
                self.customList[self.lastUsedIndex] = None
                self.lastUsedIndex -= 1
                return "The node has been successfully deleted"


    def deleteBT(self):
        self.customList = None



if __name__ == "__main__":
    bt = BinaryTree(8)
    print(bt.insertNode("Drinks"))
    print(bt.insertNode("Hot"))
    print(bt.insertNode("Cold"))
    print(bt.insertNode("Tea"))
    print(bt.insertNode("Coffee"))

    #print(bt.searchNode("Cold"))
    bt.preorder_traversal(1)
    print("------------------")
    bt.inorder_traversal(1)
    print("------------------")
    bt.postorder_traversal(1)
    print("------------------")
    bt.levelorder_traversal(1)
    print(bt.deleteNode("Tea"))
    bt.levelorder_traversal(1)
    bt.deleteBT()
    bt.levelorder_traversal(1)
        