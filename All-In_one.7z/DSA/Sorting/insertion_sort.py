def insertionSort(alist):
    for x in range(1,len(alist)):
        key = alist[x]
        y = x -1
        while y >=0 and key < alist[y]:
            alist[x],alist[y] = alist[y],alist[x]
            y -=1
        alist[y + 1] = key

    return alist

if __name__ == "__main__":
    lst = [11,2,3,7,6,8,9]
    #insertionSort(lst)
