

def merge(alist,l,m,r):
    n1 = m - l +1
    n2 = r - m

    L = [0] * (n1)
    R  = [0] * (n2)

    for i in range(0,n1):
        L[i] = alist[l + i]

    for j in range(0,n2):
        R[j] = alist[m + 1 + j]

    i = 0
    j = 0
    k = l 
    while i < n1 and j < n2:
        if L[i] <= R[j]:
            alist[k] = L[i]
            i += 1
        else:
            alist[k] = R[j]
            j +=1
        k +=1
    while i < n1:
        alist[k] = L[i]
        i += 1
        k += 1

    while j < n2:
        alist[k] = R[j]
        j += 1
        k += 1


    


def mergeSort(alist,l,r):
    if l < r:
        m = (l + (r-1))//2
        mergeSort(alist,l,m)
        mergeSort(alist,m + 1,r)
        merge(alist,l,m,r)
    return alist


if __name__ == "__main__":
    lst = [11,2,3,7,6,8,9]
    print(mergeSort(lst,0,6))