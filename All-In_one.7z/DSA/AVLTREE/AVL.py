import QueueLinkedList as queue


class AVLNOde:
    def __init__(self,data):
        self.data = data
        self.leftChild = None
        self.rightChild =None
        self.height = 1




def preorder(rootNode):
    if rootNode is None:
        return
    print(rootNode.data,end=" ")
    preorder(rootNode.leftChild)
    preorder(rootNode.rightChild)

def inorder(rootNode):
    if rootNode is None:
        return
    inorder(rootNode.leftChild)
    print(rootNode.data,end=" ")
    inorder(rootNode.rightChild)


def postorder(rootNode):
    if rootNode is None:
        return
    postorder(rootNode.leftChild)
    postorder(rootNode.rightChild)
    print(rootNode.data,end=" ")

def levelorder(rootNode):
    if not rootNode:
        return
    else:
        customQueue = queue.Queue()
        customQueue.enqueue(rootNode)
        while not customQueue.is_empty():
            root = customQueue.dequeue()
            print(root.data,end=" ")
            if root.leftChild is not None:
                customQueue.enqueue(root.leftChild)
            
            if root.rightChild is not None:
                customQueue.enqueue(root.rightChild)   

def searchNode(rootNode,value):
    if rootNode is not None:
        if  rootNode.data == value:
            return "The Value is found"
        elif value < rootNode.data:
            if rootNode.leftChild and rootNode.leftChild.data == value:
                return "The Value is found"
            else:
                searchNode(rootNode.leftChild,value)
        else:
            if rootNode.rightChild and rootNode.rightChild.data == value:
                return "The Value is found"
            else:
                searchNode(rootNode.rightChild,value)


def getHeight(rootNode):
    if not rootNode:
        return 0
    return rootNode.height


def rightRotation(disbalanceNode):

    newRoot = disbalanceNode.leftChild
    disbalanceNode.leftChild = disbalanceNode.leftChild.rightChild
    newRoot.rightChild = disbalanceNode
    disbalanceNode.height = 1 + max(getHeight(disbalanceNode.leftChild),getHeight(disbalanceNode.rightChild))
    newRoot.height = 1 + max(getHeight(newRoot.leftChild),getHeight(newRoot.rightChild))
    return newRoot

def leftRotation(disbalanceNode):
    newRoot = disbalanceNode.rightChild
    disbalanceNode.rightChild = disbalanceNode.rightChild.leftChild
    newRoot.leftChild = disbalanceNode
    disbalanceNode.height = 1 + max(getHeight(disbalanceNode.leftChild),getHeight(disbalanceNode.rightChild))
    newRoot.height = 1 + max(getHeight(newRoot.leftChild),getHeight(newRoot.rightChild))
    return newRoot


def getBalance(rootNode):
    if not rootNode:
        return 0
    return getHeight(rootNode.leftChild) - getHeight(rootNode.rightChild)

def insertNode(rootNode,nodeValue):
    if not rootNode:
        return AVLNOde(nodeValue)
    elif nodeValue < rootNode.data:
        rootNode.leftChild = insertNode(rootNode.leftChild,nodeValue)
    else:
        rootNode.rightChild = insertNode(rootNode.rightChild,nodeValue)

    rootNode.height= 1 + max(getHeight(rootNode.leftChild),getHeight(rootNode.rightChild))
    balance = getBalance(rootNode)
    if balance > 1 and nodeValue < rootNode.leftChild.data:
        return rightRotation(rootNode)

    if balance > 1 and nodeValue > rootNode.leftChild.data:
        rootNode.leftChild = leftRotation(rootNode.leftChild)
        return rightRotation(rootNode)

    if balance < -1 and nodeValue > rootNode.rightChild.data:
        return leftRotation(rootNode)

    if balance < -1 and nodeValue < rootNode.rightChild.data:
        rootNode.rightChild = rightRotation(rootNode.rightChild)
        return leftRotation(rootNode)

    return rootNode


def getMinValueNode(rootNode):
    if  rootNode is None or rootNode.leftChild is None:
        return rootNode
    return getMinValueNode(rootNode.leftChild)


def deleteNode(rootNode,nodeValue):
    if not rootNode:
        return rootNode

    elif nodeValue < rootNode.data:
        rootNode.leftChild = deleteNode(rootNode.leftChild,nodeValue)
    elif nodeValue >  rootNode.data:
        rootNode.rightChild = deleteNode(rootNode.rightChild,nodeValue)
    else:
        if rootNode.leftChild is None:
            temp = rootNode.rightChild
            rootNode = None
            return temp
        elif rootNode.rightChild is None:
            temp = rootNode.leftChild
            rootNode = None
            return temp


        temp = getMinValueNode(rootNode.rightChild)
        rootNode.data = temp.data
        rootNode.rightChild = deleteNode(rootNode.rightChild,temp.data)

    balance = getBalance(rootNode)
    if balance > 1 and getBalance(rootNode.leftChild) >=0 :
        return rightRotation(rootNode)

    if balance < -1 and getBalance(rootNode.rightChild) <= 0:
        return leftRotation(rootNode)

    if balance > 1 and getBalance(rootNode.leftChild) < 0 :
        rootNode.leftChild = leftRotation(rootNode.leftChild)
        return rightRotation(rootNode)

    if balance < -1 and getBalance(rootNode.rightChild) > 0:
        rootNode.rightChild = rightRotation(rootNode.rightChild)
        return leftRotation(rootNode)

    return rootNode


def deleteAVL(rootNode):
    rootNode.data = None
    rootNode.leftChild = None
    rootNode.rightChild = None
    return "The AVL Tree has been successfully deleted"





if __name__ == "__main__":
    newAVL = AVLNOde(30)
    newAVL = insertNode(newAVL,25)
    newAVL = insertNode(newAVL,35)
    newAVL = insertNode(newAVL,20)
    newAVL = insertNode(newAVL,15)
    newAVL = insertNode(newAVL,5)
    newAVL = insertNode(newAVL,10)
    newAVL = insertNode(newAVL,50)
    newAVL = insertNode(newAVL,60)
    newAVL = insertNode(newAVL,70)
    newAVL = insertNode(newAVL,65)
    levelorder(newAVL)
    newAVL =  deleteNode(newAVL,15)
    newAVL =  deleteNode(newAVL,15)
    newAVL =  deleteNode(newAVL,5)
    newAVL =  deleteNode(newAVL,10)
    newAVL =  deleteNode(newAVL,50)
    newAVL =  deleteNode(newAVL,60)
    newAVL =  deleteNode(newAVL,70)
    print()
    levelorder(newAVL)
    print()
    print(deleteAVL(newAVL))