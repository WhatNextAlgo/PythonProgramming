class Graph:
    def __init__(self,gdict =None):
        self.gdict = gdict if gdict is not None else {}

    
    def addEdge(self,vertex,edge):
        self.gdict[vertex].append(edge)


    def bfs(self,vertex):
        visited = [vertex]
        queue = [vertex]
        while queue:
            devertex = queue.pop(0)
            print(devertex)
            for adjacentVertex in self.gdict[devertex]:
                if adjacentVertex not in visited:
                    visited.append(adjacentVertex)
                    queue.append(adjacentVertex)


    def dfs(self,vertex):
        visited = [vertex]
        stack = [vertex]
        while stack:
            popvertex = stack.pop()
            print(popvertex)
            for adjacentVertex in self.gdict[popvertex]:
                if adjacentVertex not in visited:
                    visited.append(adjacentVertex)
                    stack.append(adjacentVertex)


if __name__ == "__main__":
    customDict = {
        "a" : ["b","c"],
        "b" : ["a","d","e"],
        "c" : ["a","e"],
        "d" : ["b","e","f"],
        "e" : ["d","f",],
        "f" : ["d","e"]
    }

    graph = Graph(customDict)
    graph.addEdge("e","c")
    print(graph.gdict["e"])
    graph.bfs("a")
    print("---")
    graph.dfs("a")
