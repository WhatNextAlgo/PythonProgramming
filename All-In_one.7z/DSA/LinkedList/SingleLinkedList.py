class Node:
    def __init__(self,value):
        self.value = value
        self.next = None

class SingleLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def __iter__(self):
        curr = self.head
        while curr:
            yield curr
            curr = curr.next

    def get_length(self):
        count = 0
        curr = self.head
        while curr:
            curr = curr.next
            count +=1
        return count

    def insert_at_beginning(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = self.head
        else:
            new_node.next = self.head
            self.head = new_node


    def insert_to_end(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = self.head
        else:
            self.tail.next = new_node
            self.tail = new_node

    def insert_at_index(self,value,index):
        length = self.get_length()
        if index > length-1:
            print("index is out of range")
            return
        curr = self.head
        ind = 0
        while ind < index-1:
            curr = curr.next
            ind += 1
        new_node = Node(value)
        next_node = curr.next
        curr.next = new_node
        new_node.next = next_node

    def traverse(self):
        if self.head is None:
            print("The singly LinkedList doens not exist")
        else:
            curr = self.head
            while curr:
                print(curr.value,end=", ")
                curr = curr.next

    def searchElement(self,nodeValue):
        
        if self.head is None:
            return "LinkedList does not exist"
        else:
            curr = self.head
            while curr is not None :
                if curr.value == nodeValue:
                    return curr.value
                curr = curr.next
            return "The value does not exist in this list"

    def delete_at_beginning(self):
        if self.head is None:
            return "LinkedList does not exist"
        else:
            if self.head == self.tail:
                self.head = None
                self.tail = None
            else:
                self.head  = self.head.next


    def delete_at_end(self):
        if self.head is None:
            return "LinkedList does not exist"
        elif self.head == self.tail:
                self.head = None
                self.tail = None
        else:
            curr = self.head 
            while curr is not None:
                if curr.next == self.tail:
                    break
                curr= curr.next
            curr.next = None
            self.tail = curr


    def delete_at_index(self,location):
        if location >= self.get_length():
            print("Index is greater then the element present in a list")
            return 
        curr = self.head
        index = 0
        while index < location -1:
            curr = curr.next
            index +=1

        next_node = curr.next
        curr.next = next_node.next

    def clear(self):
        if self.head is None:
            return 
        else:
            self.head = None
            self.tail = None


if __name__=="__main__":
    s = SingleLinkedList()
    s.insert_to_end(1)
    s.insert_to_end(2)
    s.insert_to_end(3)
    s.insert_at_index(4,1)
    s.insert_at_index(5,3)
    s.insert_at_beginning(6)
    s.insert_to_end(7)

    #s.traverse()
    #print(s.searchElement(7))

    print([node.value for node in s])
    #s.delete_at_beginning()
    #s.delete_at_end()
    s.delete_at_index(1)
    print([node.value for node in s])
    s.clear()
    print([node.value for node in s])




    
        