shoppingList = ["Milk","Cheese","Butter"]

def searchElement(lst,val):
    if val in lst:
        print(lst.index(val))
    else:
        print("element does not exist")


if __name__=="__main__" :
    shoppingList.append("Bread")
    print(shoppingList)
    shoppingList[0] = "Cream"
    print(shoppingList)
    shoppingList.extend(["White Cream","Amul Cheese"])
    print(shoppingList)
    #slice
    print(shoppingList[3:4])
    #pop()
    pop_val = shoppingList.pop()
    print(pop_val)
    #
    shoppingList.remove("Bread")
    print(shoppingList)

    #searching
    integers = [10,20,30,40,50,60]
    searchElement(integers,60)